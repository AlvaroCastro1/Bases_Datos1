<?php
require 'Conexion.php';

$id = $_GET['id'];
$sql = "SELECT*FROM Produccion WHERE idProduccion = '$id'";
$resultado = $mysqli->query($sql);
$row=$resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">
    <head>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Registro</h3>
        </div>

        <form class="form-horizontal" method="POST" action="updateProduccion.php" autocomplete="off">

            <div class="form-group">
                    <label for="idProduccion" class="col-sm-2 control-label">Id Producto</label>
                    <div class="col-sm-10">
                    <input type="idProduccion" class="form-control" id="idProduccion" name="idProduccion"
                         value="<?php echo $row['idProduccion']; ?>" required>
                     </div>
                </div>


                
                <div class="form-group">
                    <label for="fechain" class="col-sm-2 control-label">Fecha Inicio</label>
                    <div class="col-sm-10">
                    <input type="datetime" class="form-control" id="fechain" name="fechain"
                        value="<?php echo $row['fechaInicio']; ?>" required>
                     </div>
                </div>
                <div class="form-group">
                    <label for="fechafin" class="col-sm-2 control-label">Fecha Final</label>
                    <div class="col-sm-10">
                    <input type="datetime" class="form-control" id="fechafin" name="fechafin"
                       value="<?php echo $row['fechaFinal']; ?>" required>
                     </div>
                </div>
                <div class="form-group">
                    <label for="lote" class="col-sm-2 control-label">Id Lote</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="lote" name="lote"
                        value="<?php echo $row['idLote']; ?>" required>
                     </div>
                </div>

                <div class="form-group">
                    <label for="idProducto" class="col-sm-2 control-label">Id Producto</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="idProducto" name="idProducto"
                         value="<?php echo $row['idProducto']; ?>" required>
                     </div>
                </div>


                    <a href="indexProduccion.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>
