<?php

	require 'Conexion.php';

	$idNomina = $_POST['idNomina'];
	$idPago1 = $_POST['idPago1'];
	$numCunetaNomina = $_POST['numCunetaNomina'];
	$banco = $_POST['banco'];
	$montoDisponible = $_POST['montoDisponible'];
	$fechaActualizacionN = $_POST['fechaActualizacionN'];

	$sql = "UPDATE Nomina SET idPago1='$idPago1', numCunetaNomina='$numCunetaNomina', banco='$banco', montoDisponible ='$montoDisponible', fechaActualizacionN='$fechaActualizacionN'WHERE idNomina = '$idNomina'";
	$resultado = $mysqli->query($sql);


?>

<html lang="es">
	<head>

		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="row" style="text-align: center">
				<?php if($resultado){ ?>
				<h3>REGISTRO MODIFICADO</h3>
				<?php } else { ?>
				<h3>ERROR AL MODIFICAR</h3>
				<?php } ?>

				<a href="indexNomina.php" class="btn btn-primary">Regresar</a>

				</div>
			</div>
		</div>
	</body>
</html>