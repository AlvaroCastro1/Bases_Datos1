<?php
	require 'conexion.php';

	$id = $_GET['idProceso'];

	$sql = "SELECT * FROM proceso WHERE idProceso = '$id'";
	$resultado = $mysqli->query($sql);
	$row = $resultado->fetch_array(MYSQLI_ASSOC);

?>

<html lang="es"> 
	<head>

		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<link href="css/bootstrap.min.css" rel="stylesheet"> 
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script> 
		<script src="js/bootstrap.min.js"></script>
	</head>

	<body>
		<div class="container"> 
			<div class="row">
				<h3 style="text-align:center">MODIFICAR PROCESO</h3> 
			</div>

			<form class="form-horizontal" method="POST" action="updateProceso.php" autocomplete="off">
				<div class="form-group">
					<label for="idProceso" class="col-sm-2 control-label">ID PROCESO</label>
					<div class="col-sm-10">
						<input type="number" class="form-control" id="idProceso" name="idProceso" placeholder="ID PROCESO" value="<?php echo $row['idProceso']; ?>" required>
					</div>
				</div>

		<input type="hidden" id="idProceso" name="idProceso" value="<?php echo $row['idProceso']; ?>" /> 

		<div class="form-group">

		<label for="tipoProceso" class="col-sm-2 control-label">TIPO DE PROCESO</label> 
		<div class="col-sm-10">
			<input type="text" class="form-control" id="tipoProceso" name="tipoProceso" placeholder="Tipo de Proceso" value="<?php echo $row['tipoProceso']; ?>" required>
		</div>
	</div>


	<div class="form-group">
		<label for="descripcionProceso" class="col-sm-2 control-label">DESCRIPCION DEL PROCESO</label>
		<div class="col-sm-10">
			<input type="text" class="form-control" id="descripcionProceso" name="descripcionProceso" placeholder="Descripcion del Proceso" value="<?php echo $row['descripcionProceso']; ?>"> 
		</div>
	</div>

	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
			<a href="indexProceso.php" class="btn btn-default">Regresar</a> 
			<button type="submit" class="btn btn-primary">Guardar</button>
		</div>
	</div>
</form>
</div>
</body>
</html>