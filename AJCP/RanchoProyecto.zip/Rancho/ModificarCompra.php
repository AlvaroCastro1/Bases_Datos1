<?php
require 'Conexion.php';
$id = $_GET['id'];
$sql = "Select * from Compra where idCompra = '$id'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Compra</h3>
        </div>

        <form class="form-horizontal" method="POST" action="UpdateCompra.php" autocomplete="on">
            <div class="form-group">
                <label for="fecha" class="col-sm-2 control-label">Fecha</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="fecha" name="fecha" placeholder="fecha" value="<?php echo $row['fecha']; ?>" required>
                </div>
            </div>
            <input type="hidden" id="idCompra" name="idCompra" value="<?php echo $row['idCompra']; ?>">

            <div class="form-group">
                <label for="subtotal" class="col-sm-2 control-label">Subtotal</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="subtotal" name="subtotal" placeholder="subtotal" value="<?php echo $row['subtotal']; ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
            <br>

                    <a href="IndexCompra.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>