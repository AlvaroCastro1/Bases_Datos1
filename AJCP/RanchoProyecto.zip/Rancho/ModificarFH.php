<?php
require 'Conexion.php';
$id = $_GET['id'];
$sql = "Select * from FacturaHonorarios where idFacturaH = '$id'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Factura Honorarios</h3>
        </div>

        
        <form class="form-horizontal" method="POST" action="UpdateFH.php" autocomplete="on">
        <div class="form-group">
                <label for="idVisitas2" class="col-sm-2 control-label">id Visistas</label>
                <div class="col-sm-10">
                    <input type="idVisitas2" class="form-control" id="idVisitas2" name="idVisitas2" placeholder="idVisitas2" required>
                </div>
            </div>
            <div class="form-group">
                <label for="fechaEmisionH" class="col-sm-2 control-label">Fecha Emision</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="fechaEmisionH" name="fechaEmisionH" placeholder="fechaEmisionH" value="<?php echo $row['fechaEmisionH']; ?>" required>
                </div>
            </div>
            <input type="hidden" id="idFacturaH" name="idFacturaH" value="<?php echo $row['idFacturaH']; ?>">
            
            <div class="form-group">
                <label for="idFacturaH" class="col-sm-2 control-label">Fecha Vencimiento</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="fechaVencimientoH" name="fechaVencimientoH" placeholder="fechaVencimientoH" value="<?php echo $row['fechaVencimientoH']; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="fechaVencimientoH" class="col-sm-2 control-label">Fecha Vencimiento</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="fechaVencimientoH" name="fechaVencimientoH" placeholder="fechaVencimientoH" value="<?php echo $row['fechaVencimientoH']; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="lugarEmisionH" class="col-sm-2 control-label">Lugar Emision </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="lugarEmisionH" name="lugarEmisionH" placeholder="lugarEmisionH" value="<?php echo $row['lugarEmisionH']; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="lugarVencimientoH" class="col-sm-2 control-label">Lugar Vencimiento</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="lugarVencimientoH" name="lugarVencimientoH" placeholder="lugarVencimientoH" value="<?php echo $row['lugarVencimientoH']; ?>">
                </div>
            </div>


            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
            <br>

                    <a href="IndexFH.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>