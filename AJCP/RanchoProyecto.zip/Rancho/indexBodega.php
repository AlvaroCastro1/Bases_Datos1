<?php 
	$numero =0;
	require 'Conexion.php';
	$where = "";
	if(!empty($_POST)){
		$valor = $_POST['campo'];
			if(!empty($valor)){
				$where = "where idBodega like '%$valor' ";
			}
	}
$sql = "select * from Bodega $where" ;
$resultado  = $mysqli ->query($sql);

 ?>
 <html lang="es"> <!-- inicio de la pagina de html-->
 <head> <!-- inicio del head-->

 	<meta charset="utf-8"> <!-- tipologia  -->
 	<meta name="viewport" content="width=device-width, initial-scale=1"> <!-- escalas -->
	<link href = "css/bootstrap.min.css" rel="stylesheet"><!-- para css -->
	<link href = "css/bootstrap-theme.min.css" rel="stylesheet"><!--  para css-->
	<script src="js/jquery-3.1.1.min.js"></script><!-- para javascript -->
	<script src="js/bootstrap.min.js"></script><!-- para javacript-->
 </head><!-- fin del head -->
 <body><!-- inicio del body-->
 	<div class = "container"> <!-- contenedor de container-->
 		<div class="row"><!-- contenedor de row -->
 			<h2 style="text-align:center"> BODEGA (RANCHO)</h2><!-- linea de texto-->
 		</div><!-- fin del row -->
 		<div class="row"><!-- inicio del row -->
 			<a href="nuevoBodega.php" class="btn btn-primary"> nuevo registro</a><!-- boton del nuevo registro-->
 			<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                <b>Id: </b><input type="text" id="campo" name="campo" />
                <input type="submit" id="enviar" name="enviar" value="Buscar" class="btn btn-info" />
            </form>
 		</div>
 		<br>
 		<div class = "row table-responsive"> <!--tabla responsiva -->
 			<table class = "table table-striped"><!-- inicio de la tabla -->
 				<thead>
 					<tr>
 						<th>ID</th> <!-- agregamos columnas -->
 						<th>Cantidad</th>
 						<th>Fecha</th>
 						<th></th>
 						<th></th>

 					</tr>
 				</thead>

 				<tbody>
 					<?php while($row = $resultado ->fetch_array(MYSQLI_ASSOC)){ ?> <!--si el resultado es correcto enviamos lo siguiente -->
 						<tr>
 							<td><?php echo $row['idBodega']; ?></td><!--metemos la id y los demas campos que tenemos en la bd -->
 						<td><?php echo $row['cantidadB']; ?></td>
 						<td><?php echo $row['fechaActualizadaB']; ?></td>
 						<td><a href="modificarBodega.php?idBodega= <?php echo $row['idBodega'];?>"><span class="glyphicon glyphicon-pencil"></a></td>
 							<!--agregamos el boton de modificar, que es un cambio de pagina -->
 						<td><a href="'<?php $numero = $row['idBodega']; ?>'" data-href="" data-toggle = "modal"  data-target="#confirm-delete"><span class="glyphicon glyphicon-trash"></span></a></td><!-- agregamos el boton eliminar donde es una pregunta -->
 						</tr>

 					<?php } ?>
 				</tbody>
 			</table>
 		</div>
 		<div class ="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden = "true">
 			<!-- creamos la pregunta para la eliminacion-->
 			<div class="modal-dialog"><!-- inciamos los modaldialog-->
 				<div class="modal-content"><!-- contenidos-->
 					<div class="modal-header"><!-- header-->
 						<button type="button" class ="close" date-dismiss= "modal" aria-hidden = "true">&times;</button>
 						<!-- como funciona nuestra ventana-->
 						<h4 class = "modal-title" id="myModalLabel"> Eliminar registro</h4><!-- titulo de la ventana-->
 					</div>
 					<div class="modal-body">
 							¿Desea eliminar este registro?<!-- pregunta-->
 					</div>
 					<div class= "modal-footer">
 						<button type="button" class="btn btn-default" data-dismiss="modal">cancel</button>
 						<a class="btn btn-danger btn-ok" href="eliminarBodega.php?id=<?php if($numero == 1){ echo($numero);}else{ echo($numero-1);}
 						
 						$numero = null; 
 						?>" >Delete</a><!-- se agregan botones para eliminar-->
 					 </div>
 				</div>
 			</div>
 		</div>
 	</div>
 </body>
 </html>

 <!-- el codigo no se podia borrar, tuve que crear una variable nueva, y pasarle los valores de id, a $numero donde despues se los pase directamente al boton, 