<!DOCTYPE html>
<html lang="es"><!-- se inicializa html-->
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-theme.css" rel="stylesheet">
	<script src="js/jquery-3.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script><!-- los javascripts y css de las paginas-->
</head>
<body>
	<div class="conteiner">
		<div class="row">
			<h3 style= "text-align: center;"> NUEVO REGISTRO</h3>
			<!-- linea de texto para el registro-->
		</div>
		<form class="form-horizontal" method="POST" action="guardarBodega.php" autocomplete="off">
			<div class="form-group">
				<label for="cantidad" class="col-sm-2 control-label">Cantidad</label>
				<div class="col-sm-10">
					<input type="text" class="form-control" id="cantidad" name="cantidad" placeholder="Cantidad" required>
				</div><!-- son las etiquetas y los cuadros de texto que tiene la pagina para el registro-->
			</div>
			<div class="form-group">
				<label for="fecha" class="col-sm-2 control-label">Fecha</label>
				<div class="col-sm-10">
					<input type="date" class="form-control" id="fecha" name="fecha" placeholder="fecha"required>
				</div><!-- son las etiquetas y los cuadros de texto que tiene la pagina para el registro-->
			</div>
		
			<div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
							<a href="indexBodega.php" class="btn btn-default">Regresar</a>
							<button type="submit" class="btn btn-primary">Guardar
								<!-- se agregan los botones para poder regresar o guardar-->
						</div>
					</div>
					</form>
	</div>
</body>
</html>