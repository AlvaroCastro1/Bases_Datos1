<?php
//se conecta a la base de datos
require 'conexion.php';
// se le asigna un valor a cada una de las variables
$idProducto = $_POST['idProducto'];
$idStock1 = $_POST['idStock1'];
$nombreProducto = $_POST['nombreProducto'];
$precioProducto = $_POST['precioProducto'];
$tipoUnidad = $_POST['tipoUnidad'];
$cantidad = $_POST['cantidad'];
$descripcion = $_POST['descripcion'];
//se le dan nuevos valores a cada uno de los campos
$sql = "UPDATE Producto SET idStock1='$idStock1' , nombreProducto='$nombreProducto', precioProducto = '$precioProducto', tipoUnidad = '$tipoUnidad', cantidad = '$cantidad', descripcion = '$descripcion' WHERE idProducto = '$idProducto'";
$resultado = $mysqli->query($sql);
?>

<html lang="es">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row" style="text-align:center">
                <!--se da el resultado del registro-->
                <?php if($resultado){ ?>
                    <h3>Registro modificado</h3>
                    <?php }else{ ?>
                        <h3>Error al Modificar</h3>
                        <?php } ?>
                        <a href="indexProducto.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>
    </body>
</html>
