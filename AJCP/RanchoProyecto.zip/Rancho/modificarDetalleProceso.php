<?php
	require 'Conexion.php';

	$id= $_GET['id'];
	$sql ="SELECT * FROM DetalleProceso WHERE idDetalleProceso='$id'";
	$resultado=$mysqli->query($sql);
	$row=$resultado->fetch_array(MYSQLI_ASSOC);

	$query=mysqli_query($mysqli,"SELECT idProceso FROM Proceso");
	$query1=mysqli_query($mysqli,"SELECT idInsumo,nombre FROM Insumos");

?>

<html lang="es">
	<head>
		<meta name= "viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align:center"> MODIFICAR REGISTRO </h3>
			</div>
			<form class="form-horizontal" method="POST" action="updateDetalleProceso.php" autocomplete="off">
				<div class="form-group">
					<label for="idDetalleProceso" class="col-sm-2 control-label">ID DETALLE PROCESO</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="idDetalleProceso" name="idDetalleProceso" value="<?php echo $row['idDetalleProceso']; ?>" required>
					</div>
				</div>

				<div class="form-group">
					<label for="idProceso" class="col-sm-2 control-label">ID PROCESO</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="idProceso" name="idProceso" placeholder="idProceso" required>
					</div>
				</div>

				<div class="form-group">
					<label for="idInsumo1" class="col-sm-2 control-label"> INSUMO </label>
						<div class="col-sm-10">
							<select class="form-control" id="idInsumo1" name="idInsumo1">
								<?php while ($datos=mysqli_fetch_array($query1)) 
									{
								?>
								<option value="<?php echo $datos['idInsumo']?>"><?php echo $datos['nombre']?></option>
								<?php
									}
								?>
							</select>
						</div>
				</div>

				<div class="form-group">
					<label for="cantidadInsumo" class="col-sm-2 control-label"> CANTIDAD DE INSUMO </label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="cantidadInsumo" name="cantidadInsumo" value="<?php echo $row['cantidadInsumo']; ?>" required required>
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="indexDetalleProceso.php" class="btn btn-default"> Regresar </a>
						<button type="submit" class="btn btn-primary"> Guardar </button>	
					</div>
				</div>
			</form>
		</div>
	</body>
</html>