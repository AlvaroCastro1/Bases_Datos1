<?php
require 'conexion.php';
$idProducto = $_GET['idOferta'];
$sql = "Select * from Ofertas where idOferta = '$idProducto'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Ofertas</h3>
        </div>

        <form class="form-horizontal" method="POST" action="updateOfertas.php" autocomplete="off">
            <div class="form-group">
                <label for="idOferta" class="col-sm-2 control-label">idOferta</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="idOferta" name="idOferta" placeholder="idOferta" value="<?php echo $row['idOferta']; ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label for="idLote1" class="col-sm-2 control-label">Lote</label>
                <div class="col-sm-10">
                    <input type="idLote1" class="form-control" id="idLote1" name="idLote1" placeholder="idLote1" value="<?php echo $row['idLote1']; ?>">
                </div>
            </div>
            <input type="hidden" id="idLote1" name="idLote1" value="<?php echo $row['idLote1']; ?>">

            <div class="form-group">
                <label for="precioOferta" class="col-sm-2 control-label">precioOferta</label>
                <div class="col-sm-10">
                    <input type="precioOferta" class="form-control" id="precioOferta" name="precioOferta" placeholder="precioOferta" value="<?php echo $row['precioOferta']; ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
            <br>
                    <a href="indexOfertas.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>
