<?php 
    require 'Conexion.php';
    $where = "";

    if(!empty($_POST))
    {
        $valor = $_POST['campo'];
        if(!empty($valor)){
            $where = "WHERE fechaVenta LIKE '%$valor'";
        }
    }
    $sql = "SELECT* FROM venta $where";
    $resultado = $mysqli->query($sql);
    
?>

<html lang="es">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/jquery-3.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <title>Index Venta</title>


    </head>

    <body style="background: #F0F2F0;  /* fallback for old browsers */background: -webkit-linear-gradient(to right, #000C40, #F0F2F0);  /* Chrome 10-25, Safari 5.1-6 */ background: linear-gradient(to right, #000C40, #F0F2F0); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */"> 
        <div class="container" style="background-color:white">
            <div class="row">
                <h2 style="text-align:center">Venta</h2>
            </div>

            <div class="row">
                <a href="NuevaVenta.php" class="btn btn-primary">Nueva Venta</a>
                <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                <b>Fecha: </b><input type="text" id="campo" name="campo" />
                <input type="submit" id="enviar" name="enviar" value="Buscar" class="btn btn-info" />

            </div>

            <br>
            
            <div class="row table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Fecha Venta</th>
                            <th>IVA</th>
                            <th>Total</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php while($row = $resultado->fetch_array(MYSQLI_ASSOC)) { ?>
                            <tr>
                                <td><?php echo $row['idVenta']; ?></td>
                                <td><?php echo $row['fechaVenta']; ?></td>
                                <td><?php echo $row['iva']; ?></td>
                                <td><?php echo $row['total']; ?></td>
                                <td><a href="modificarVenta.php?id=<?php echo $row['idVenta']; ?>" ><span class="glyphicon 
                                glyphicon-pencil"></span></a></td>
                                <td><a href="eliminarVenta.php?id=<?php echo $row['idVenta']; ?>" data-toggle="modal" data-target="#confirm-delete"><span class="glyphicon glyphicon-trash"></span>
                                </a></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!--Modal-->
        <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel"> Eliminar Registro</h4>
                    </div>

                    <div class="modal-body">
                        ¿Desea Eliminar este Registro?
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-defualt" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-danger btn-ok">Delete</a>
                    </div>
                </div>
            </div>
        </div>

    </body>
</html>