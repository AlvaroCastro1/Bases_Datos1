<!--DIEGO GOMEZ TAGLE GONZALEZ-->
<?php
	require 'conexion.php';
	$where= "";
	if(!empty($_POST)){
		$valor=$_POST['campo'];
		if(!empty($valor)){
			$where="WHERE idCompra1 LIKE'%$valor'";
		}
	}
	$sql="SELECT*FROM DetalleCompra $where";
	$resultado=$mysqli->query($sql);
?>
<html lang="es">
<head>
	<meta name= "viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-theme.css" rel="stylesheet">
	<script src="js/jquery-3.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class= "row">
			<h2 style="text-align: center">Detalle Compra </h2>
		</div>

		<div class="row">
			<a href="nuevo-detallecompra.php" class="btn btn-primary">Nuevo Registro</a>

			<form action= "<?php $_SERVER['PHP_SELF']; ?>" method="POST">
				<b>idCompra: </b><input type="text" id="campo" name="campo"/>
				<input type="submit" id="enviar" value="Buscar" class="btn btn-info" />
			</form>
		</div>

		<br>
		<div class="row table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>IdDetalleCompras</th>
						<th>IdCompra</th>
						<th>IdProveedor</th>
						<th>IdInsumo</th>
						<th>cantidad de Insumo</th>
						<th>Precio Unitario</th>
						<th></th>
						<th></th>
					</tr>
				</thead>

				<tbody>
					<?php while ($row= $resultado->fetch_array(MYSQLI_ASSOC)){ ?>
						<tr>
							<td> <?php echo $row['idDetalleCompras']; ?> </td>
							<td> <?php echo $row['idCompra1']; ?></td>
							<td> <?php echo $row['idProveedor1']; ?></td>
							<td> <?php echo $row['idInsumo1']; ?> </td>
							<td> <?php echo $row['cantidadInsumo']; ?> </td>
							<td> <?php echo $row['precioUnitario']; ?> </td>

							<td> <a href="modificar-detallecompra.php?id=<?php echo $row['idDetalleCompras']; ?>"><span class="=glyphicon glyphicon-pencil"></span></a></td>
							<td> <a href="eliminar-detallecompra.php?id=<?php echo $row['idDetalleCompras'];?> "> <span class="glyphicon glyphicon-trash"> </span> </a> </td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>


	<!--Modal-->
	<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> 
					<h4 class="modal-title" id="myModalLabel">ELIMINAR REGISTRO </h4>
				</div>
				<div class="modal-body"> 
					¿Desea eliminar este registro?
				</div>

				<div class="modal-footer"> 
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar </button>

					<a class="btn btn-danger btn-ok">BORRAR </a>
				</div>
			</div>
		</div>
	</div>
</body>
</html>