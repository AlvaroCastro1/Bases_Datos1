<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="">
    </head>
    <body>
    <body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Asistencia del Empleado</h3>
        </div>
    <form class="form-horizontal" method="POST" action="GuardarAsistencia.php" autocomplete="on">

        <div class="form-group">
            <label for="nombre" class="col-sm-2 control-label">ID del empleado:</label>
                <div class="col-sm-10">
                <input type="nombre" class="form-control" id="idEmpleado1" name="idEmpleado1" placeholder="000000" required>
            </div>
        </div>

        <div class="form-group">
            <label for="asistencia" class="col-sm-2 control-label">Asistió a laborar:</label>
                <div class="col-sm-10">
                    <label class="radio-inline">
                        <input type="radio" name="asistencia" id="asistencia" value="1" checked>SI
                    </label>
                        <label class="radio-inline">
                    <input type="radio" name="asistencia" id="asistencia" value="0" checked>NO
                 </label>
            </div>
        </div>

        <div class="form-group">
            <label for="falta" class="col-sm-2 control-label">Faltó a su trabajo:</label>
                <div class="col-sm-10">
                    <label class="radio-inline">
                        <input type="radio" name="falta" id="falta" value="1" checked>SI
                    </label>
                        <label class="radio-inline">
                        <input type="radio" name="falta" id="falta" value="0" checked>NO
                </label>
            </div>
        </div>

        <div class="form-group">
            <label for="horasExtra" class="col-sm-2 control-label">Horas extras de trabajo:</label>
                <div class="col-sm-10">
                <input type="horasExtra" class="form-control" id="horasExtra" name="horasExtra" placeholder="Total 0" required>
            </div>
        </div>

        <div class="form-group">
            <label for="fechaA" class="col-sm-2 control-label">Fecha registro de asistencia:</label>
                <div class="col-sm-10">
                <input type="fechaA" class="form-control" id="fechaA" name="fechaA" placeholder="0000-00-00" required>
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <a href="InicioAsistencia.php" class="btn btn-default">Regresar</a>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </div>
</form>
</div>
</body>
</html>
</body>
</html> 

