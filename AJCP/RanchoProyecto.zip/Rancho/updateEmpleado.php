<?php
require 'Conexion.php';
$id = $_GET['id'];
$nombreEmpleado = $_POST['nombreEmpleado'];
$RFC= $_POST['RFC'];
$NSS=$_POST['NSS'];
$correo = $_POST['correoE'];
$telefono = $_POST['telefono'];
$direccion =$_POST['direccion'];
$nocuenta_bancaria=$_POST['noCuentaBancaria'];

$sql = "UPDATE empleado SET nombreEmpleado='$nombreEmpleado', RFC='$RFC', NSS='$NSS', correoE='$correo', telefono='$telefono',direccion='$direccion',noCuentaBancaria='$nocuenta_bancaria'  WHERE idEmpleado = '$id'";
$resultado = $mysqli->query($sql);

?>

<html lang="es">
    <head>
        <meta name="vieport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/jquery-3.1.1.min.js"></script>
    </head>

    <body>
        <div class="contrainer">
            <div class="row">
                <div class="row"  style="text-aLign:center">
                <?php if($resultado) { ?>
                <h3>REGISTRO MODIFICADO</h3>
                <?php } else { ?>
                <h3>ERROR AL MODIFICAR</h3>
                <?php } ?>

                <a  href="indexEmpleado.php" class="btn btn-primary">REGRESAR</a>

                </div>
            </div>
        </div>
    </body>
</html>
