<!--DIEGO URIEL DOMINGUEZ GUZMAN-->
<?php
		require 'conexion.php';
	$idDetalleVentas=$_POST['idDetalleVentas'];
	$idVenta1=$_POST['idVenta1'];
	$idProducto1=$_POST['idProducto1'];
	$cantidadNR=$_POST['cantidadNR'];
	$subtotal=$_POST['subtotal'];


		$sql="UPDATE DetalleVentas SET idVenta1='$idVenta1',idProducto1='$idProducto1',cantidadNR='$cantidadNR',subtotal='$subtotal'WHERE idDetalleVentas='$idDetalleVentas'";	
		$resultado=$mysqli->query($sql);
?>

<html lang="es">
	<head>
		<meta name= "viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="row" style="text-align: center">
				<?php if($resultado){ ?>
				<h3>REGISTRO MODIFICADO </h3>
				<?php } else{ ?>
				<h3>ERROR AL MODIFICAR</h3>
				<?php } ?>

			<a href="index-detalleventas.php" class="btn btn.primary">Regresar</a>
				</div>
			</div>
		</div>
	</body>
</html>