
<html lang="es">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/query-3.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <title>Registro Venta</title>  
    <body style="background: #fc00ff;  /* fallback for old browsers */background: -webkit-linear-gradient(to right, #00dbde, #fc00ff);  /* Chrome 10-25, Safari 5.1-6 */background: linear-gradient(to right, #00dbde, #fc00ff); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */">
        <div class="container" style="background-color: white">
            <div class="row">
                <div class="col">
                    <h3 style="text-align:center">NUEVA VENTA</h3>
                </div>
            </div>
                <div class="row">
                    <div class="col">
                        <form class="form-horizontal" method="POST" action="guardarVenta.php" autocomplete="off">
                            
                            <div class="form-group row">
                                <label for="fechaVenta" class="col-sm-2 control-label">Fecha Venta</label>
                                <div class="col-sm-10">
                                    <input  type="date" class="form-control" id="fechaVenta" name="fechaVenta" 
                                    placeholder="Fecha en que se realizo la venta" required>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <label for="IVA" class="col-sm-2 control-label">IVA</label>
                                <div class="col-sm-10">
                                    <input type="number" min="0" max="16" step=".1" class="form-control" id="IVA" name="IVA" placeholder="IVA" required>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <label for="Total" class="col-sm-2 control-label">TOTAL</label>
                                <div class="col-sm-10">
                                    <input type="number" min="0" step="0.01" class="form-control" id="Total" name="Total" placeholder="Total" required>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <a href="indexVenta.php" class="btn btn-defauult">Regresar</a>
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>  
    </body>

</html>



