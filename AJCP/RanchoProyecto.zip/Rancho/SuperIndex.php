<?php
    require 'Conexion.php';
?>
<html lang="es">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    
    <div class="container">
        <div class="row">
            <!--Texto alineado al centro que forma el titulo de la pagina -->
            <h2 style="text-align: center">Rancho</h2>
        </div>

        <div class="row">
            <a href="InicioAsistencia.php" class="btn btn-primary">Asistencia</a>   

        </div>
        <div class="row">
            <br>
            <a href="indexBodega.php" class="btn btn-primary">Bodega</a>   
        </div>
        <div class="row">
            <br>
            <a href="indexCargo.php" class="btn btn-primary">Cargo</a>   
        </div>
        <div class="row">
            <br>
            <a href="IndexCompra.php" class="btn btn-primary">Compra</a>   
        </div>
        <div class="row">
            <br>
            <a href="IndexCT.php" class="btn btn-primary">Compras Totales</a>   
        </div>
        <div class="row">
            <br>
            <a href="index-contrato.php" class="btn btn-primary">Contrato</a>   
        </div>
        <div class="row">
            <br>
            <a href="indexDepto.php" class="btn btn-primary">Departamento</a>   
        </div>
        <div class="row">
            <br>
            <a href="index-detallecompra.php" class="btn btn-primary">Detalle de compra</a>   
        </div>
        
        <div class="row">
            <br>
            <a href="indexDetalleProceso.php" class="btn btn-primary">Detalle de proceso</a>   
        </div>
        <div class="row">
            <br>
            <a href="indexDetalleProduccion.php" class="btn btn-primary">Detalle de produccion</a>   
        </div>
        <div class="row">
            <br>
            <a href="index-detalleventas.php" class="btn btn-primary">Detalle de ventas</a>   
        </div>
        <div class="row">
            <br>
            <a href="indexEgresos.php" class="btn btn-primary">Egresos</a>   
        </div>
        <div class="row">
            <br>
            <a href="indexEmpleado.php" class="btn btn-primary">Empleado</a>   
        </div>
        
         <div class="row">
            <br>
            <a href="IndexFH.php" class="btn btn-primary">Factura honorarios</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexFacturaventa.php" class="btn btn-primary">Factura ventas</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexHonorarios.php" class="btn btn-primary">Honorarios</a>   
        </div>
         
         <div class="row">
            <br>
            <a href="indexInsumo.php" class="btn btn-primary">Insumos</a>   
        </div>
         <div class="row">
            <br>
            <a href="index-jornada.php" class="btn btn-primary">Jornada</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexLote.php" class="btn btn-primary">Lote</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexNomina.php" class="btn btn-primary">Nomina</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexOfertas.php" class="btn btn-primary">Ofertas</a>   
        </div>
         
         <div class="row">
            <br>
            <a href="index-periodo.php" class="btn btn-primary">Periodo</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexProceso.php" class="btn btn-primary">Proceso</a>   
        </div>
         <div class="row">
            <br>
            <a href="index.php" class="btn btn-primary">Produccion</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexProducto.php" class="btn btn-primary">Producto</a>   
        </div>
         <div class="row">
            <br>
            <a href="IndexProv.php" class="btn btn-primary">Proveedores</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexServicio.php" class="btn btn-primary">Servicio</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexStock.php" class="btn btn-primary">Stock</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexVenta.php" class="btn btn-primary">Venta</a>   
        </div>
         <div class="row">
            <br>
            <a href="indexVisitas.php" class="btn btn-primary">Visitas</a>   
        </div>

        


        
        </div>
    </div>


</body>

</html>>