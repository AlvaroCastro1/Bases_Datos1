
<html lang="es">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align: center">NUEVO REGISTRO</h3>

			</div>
			<form class="form-horizontal" method="POST" action="guardarProduccion.php" autocomplete="off">

				<div class="form-group">
                    <label for="idProduccion" class="col-sm-2 control-label">Id Produccion</label>
                    <div class="col-sm-10">
                    <input type="idProduccion" class="form-control" id="idProduccion" name="idProduccion"
                         placeholder="IdProduccion" required>
                     </div>
				</div>


				
                <div class="form-group">
                    <label for="fechain" class="col-sm-2 control-label">Fecha Inicio</label>
                    <div class="col-sm-10">
                    <input type="date" class="form-control" id="fechain" name="fechain"
                         placeholder="AAAA/MM/DD" required>
                     </div>
				</div>
                <div class="form-group">
                    <label for="fechafin" class="col-sm-2 control-label">Fecha Final</label>
                    <div class="col-sm-10">
                    <input type="date" class="form-control" id="fechafin" name="fechafin"
                         placeholder="AAAA/MM/DD" required>
                     </div>
				</div>
				<div class="form-group">
                    <label for="lote" class="col-sm-2 control-label">Id Lote</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="lote" name="lote"
                         placeholder="lote" required>
                     </div>
				</div>

				<div class="form-group">
                    <label for="idProducto" class="col-sm-2 control-label">Id Producto</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="idProducto" name="idProducto"
                         placeholder="Id Producto" required>
                     </div>
				</div>


				
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="index.php" class="btn btn-default">regresar </a>
						<button type="submit" class="btn btn-primary">Guardar </button>
					
					</div>
				</div>
			</form>
		</div>
	</body>
</html>