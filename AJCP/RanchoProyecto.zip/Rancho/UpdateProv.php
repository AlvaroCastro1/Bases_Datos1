<?php
require 'Conexion.php';
$id = $_POST['idProveedor'];
$razonSocial = $_POST['razonSocial'];
$estado = $_POST['estado'];
$municipio = $_POST['municipio'];
$colonia = $_POST['colonia'];
$calle = $_POST['calle'];
$numExt = $_POST['numExt'];
$numInt = $_POST['numInt'];
$CP = $_POST['CP'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];

$sql = "UPDATE Proveedores SET razonSocial='$razonSocial' , estado = '$estado', municipio = '$municipio', colonia = '$colonia', calle = '$calle', numExt = '$numExt', numInt = '$numInt', CP = '$CP', telefono = '$telefono', correo = '$correo' WHERE idProveedor = '$id'";
$resultado = $mysqli->query($sql);
?>

<html lang="es">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row" style="text-align:center">
                <?php if($resultado){ ?>
                    <h3>Registro modificado</h3>
                    <?php }else{ ?>
                        <h3>Error al Modificar</h3>
                        <?php } ?>
                        <a href="IndexProv.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>
    </body>
</html>