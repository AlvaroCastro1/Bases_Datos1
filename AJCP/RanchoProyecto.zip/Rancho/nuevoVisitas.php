<html lang="es">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align: center">NUEVO REGISTRO</h3>
			</div>

			<form class="form-horizontal" method="POST" action="guardarVisitas.php" autocomplete="off">
				<div class="form-group">
					<label for="idVisitas" class="col-sm-2 control-label">IdVisitas</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="idVisitas" name="idVisitas" placeholder="IdVisitas" required>
					</div>
				</div>

				<div class="form-group">
					<label for="idServicio1" class="col-sm-2 control-label">IdServicio1</label>
					<div class="col-sm-10">
						<input type="idServicio1" class="form-control" id="idServicio1" name="idServicio1" placeholder="IdServicio1" required>
					</div>
				</div>

				<div class="form-group">
					<label for="servicio" class="col-sm-2 control-label">Servicio</label>
					<div class="col-sm-10">
						<input type="servicio" class="form-control" id="servicio" name="servicio" placeholder="servicio" required>
					</div>
				</div>

				<div class="form-group">
					<label for="fechaServicioI" class="col-sm-2 control-label">FechaServicioI</label>
					<div class="col-sm-10">
						<input type="fechaServicioI" class="form-control" id="fechaServicioI" name="fechaServicioI" placeholder="FechaServicioI" required>
					</div>
				</div>

				<div class="form-group">
					<label for="fechaServicioF" class="col-sm-2 control-label">FechaServicioF</label>
					<div class="col-sm-10">
						<input type="fechaServicioF" class="form-control" id="fechaServicioF" name="fechaServicioF" placeholder="FechaServicioF" required>
					</div>
				</div>

				<div class="form-group">
					<label for="pagoServicio" class="col-sm-2 control-label">PagoServicio</label>
					<div class="col-sm-10">
						<input type="pagoServicio" class="form-control" id="pagoServicio" name="pagoServicio" placeholder="PagoServicio" required>
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="indexVisitas.php" class="btn btn-default">Regresar</a>
						<button type="submit" class="btn btn-primary">Guardar</button>
					</div>
				</div>
			</form>
		</div>
	</body>
</html>