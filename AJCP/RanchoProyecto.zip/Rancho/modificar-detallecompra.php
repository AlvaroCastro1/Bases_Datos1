<!--DIEGO GOMEZ TAGLE GONZALEZ-->
<?php
	require 'conexion.php';
	$id= $_GET['id'];
	$sql ="SELECT*FROM DetalleCompra WHERE idDetalleCompras='$id'";
	$resultado=$mysqli->query($sql);
	$row=$resultado->fetch_array(MYSQLI_ASSOC);


	$query=mysqli_query($mysqli,"SELECT idCompra FROM Compra");
	$query1=mysqli_query($mysqli,"SELECT idProveedor,razonSocial FROM Proveedores");
	$query2=mysqli_query($mysqli,"SELECT idInsumo,nombre FROM Insumos");


?>

<html lang="es">
	<head>
		<meta name= "viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align:center">MODIFICAR REGISTRO</h3>
			</div>
			<form class="form-horizontal" method="POST" action="update-detallecompra.php" autocomplete="off">
				<div class="form-group">
					<label for="idDetalleCompras" class="col-sm-2 control-label">ID DETALLE COMPRA</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="idDetalleCompras" name="idDetalleCompras" value="<?php echo $row['idDetalleCompras']; ?>" required>
					</div>
				</div>


				<div class="form-group">
					<label for="idCo" class="col-sm-2 control-label">ID COMPRA</label>
					<div class="col-sm-10">
						<select class="form-control" id="idCompra1" name="idCompra1">
								<?php while ($datos=mysqli_fetch_array($query)) 
									{
								?>
								<option value="<?php echo $datos['idCompra']?>"><?php echo $datos['idCompra']?></option>
								<?php
									}
								?>
							</select>
					</div>
				</div>

				<div class="form-group">
					<label for="idProveedor" class="col-sm-2 control-label">PROVEEDOR</label>
						<div class="col-sm-10">
							<select class="form-control" id="idProveedor1" name="idProveedor1">
								<?php while ($datos=mysqli_fetch_array($query1)) 
									{
								?>
								<option value="<?php echo $datos['idProveedor']?>"><?php echo $datos['razonSocial']?></option>
								<?php
									}
								?>
							</select>
						</div>
				</div>

				<div class="form-group">
					<label for="idInsumo1" class="col-sm-2 control-label">INSUMO</label>
						<div class="col-sm-10">
							<select class="form-control" id="idInsumo1" name="idInsumo1">
								<?php while ($datos=mysqli_fetch_array($query2)) 
									{
								?>
								<option value="<?php echo $datos['idInsumo']?>"><?php echo $datos['nombre']?></option>
								<?php
									}
								?>
							</select>
						</div>
				</div>

				<div class="form-group">
					<label for="cantidadInsumo" class="col-sm-2 control-label">CANTIDAD DEL INSUMO</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="cantidadInsumo" name="cantidadInsumo" value="<?php echo $row['cantidadInsumo']; ?>" required required>
					</div>
				</div>

				<div class="form-group">
					<label for="precioUnitario" class="col-sm-2 control-label">PRECIO UNITARIO</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="precioUnitario" name="precioUnitario" value="<?php echo $row['precioUnitario']; ?>" required required>
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="index-contrato.php" class="btn btn-default">regresar </a>
						<button type="submit" class="btn btn-primary">Guardar </button>	
					</div>
				</div>
			</form>
		</div>
	</body>
</html>