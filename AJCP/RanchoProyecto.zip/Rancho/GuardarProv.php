<?php
require 'Conexion.php';
$razonSocial = $_POST['razonSocial'];
$estado = $_POST['estado'];
$municipio = $_POST['municipio'];
$colonia = $_POST['colonia'];
$calle = $_POST['calle'];
$numExt = $_POST['numExt'];
$numInt = $_POST['numInt'];
$CP = $_POST['CP'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];

//la variable sql almacena la sentencia para meter datos en la bd
$sql = "INSERT INTO Proveedores (razonSocial, estado, municipio, colonia, calle, numExt, numInt, CP, telefono, correo ) VALUES(
            '$razonSocial', '$estado', '$municipio', '$colonia', '$calle', '$numExt', '$numInt', '$CP', '$telefono', '$correo')";
            //se especifica que variable va en cada campo

$resultado = $mysqli->query($sql);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="row" style="text-align:center">
                <?php if ($resultado) { ?>
                    <h3>Registro Guardado</h3>
                <?php } else { ?>
                    <h3>Error al Guardar</h3>
                <?php } ?>
                <a href="IndexProv.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>

    </div>
</body>

</html>