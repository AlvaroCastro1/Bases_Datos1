<?php
require 'Conexion.php';
$id = $_GET['id'];
$fecha=$_POST['fechaVenta'];
$ivaventa = $_POST['IVA'];
$totalVenta= $_POST['Total'];

$sql = "UPDATE venta SET fechaVenta='$fecha',IVA='$ivaventa', Total='$totalVenta'  WHERE idVenta = '$id'";
$resultado = $mysqli->query($sql);

?>

<html lang="es">
    <head>
        <meta name="vieport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/jquery-3.1.1.min.js"></script>
    </head>

    <body>
        <div class="contrainer">
            <div class="row">
                <div class="row"  style="text-aLign:center">
                <?php if($resultado) { ?>
                <h3>REGISTRO MODIFICADO</h3>
                <?php } else { ?>
                <h3>ERROR AL MODIFICAR</h3>
                <?php } ?>

                <a  href="indexVenta.php" class="btn btn-primary">REGRESAR</a>

                </div>
            </div>
        </div>
    </body>
</html>
