<?php
	require 'Conexion.php';

	$idNomina = $_GET['id'];

	$sql = "SELECT * FROM Nomina WHERE idNomina = '$idNomina'";
	$resultado = $mysqli->query($sql);
	$row = $resultado->fetch_array(MYSQLI_ASSOC);

	


?>
<html lang="es">
	<head>

		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align: center">MODIFICAR REGISTRO</h3>
			</div>

			<form class="form-horizontal" method="POST" action="updateNomina.php" autocomplete="off">
				<div class="form-group">
					<label for="idNomina" class="col-sm-2 control-label">IdNomina</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="idNomina" name="idNomina" placeholder="IdNomina" value="<?php echo $row['idNomina']; ?>" required>
					</div>
				</div>

				<input type="hidden" id="idNomina" name="idNomina" value="<?php echo $row['idNomina']; ?>" />

				<div class="form-group">
					<label for="idPago1" class="col-sm-2 control-label">IdPago1</label>
					<div class="col-sm-10">
						<input type="idPago1" class="form-control" id="idPago1" name="idPago1" placeholder="IdPago1" value="<?php echo $row['idPago1']; ?>" required>
					</div>
				</div>

				<div class="form-group">
					<label for="numCunetaNomina" class="col-sm-2 control-label">NumCunetaNomina</label>
					<div class="col-sm-10">
						<input type="numCunetaNomina" class="form-control" id="numCunetaNomina" name="numCunetaNomina" placeholder="NumCunetaNomina" value="<?php echo $row['numCunetaNomina']; ?>" >
					</div>
				</div>

				<div class="form-group">
					<label for="banco" class="col-sm-2 control-label">Banco</label>
					<div class="col-sm-10">
						<input type="banco" class="form-control" id="banco" name="banco" placeholder="Banco" value="<?php echo $row['banco']; ?>" >
					</div>
				</div>

				<div class="form-group">
					<label for="montoDisponible" class="col-sm-2 control-label">MontoDisponible</label>
					<div class="col-sm-10">
						<input type="montoDisponible" class="form-control" id="montoDisponible" name="montoDisponible" placeholder="MontoDisponible" value="<?php echo $row['montoDisponible']; ?>" >
					</div>
				</div>

				<div class="form-group">
					<label for="fechaActualizacionN" class="col-sm-2 control-label">FechaActualizacionN</label>
					<div class="col-sm-10">
						<input type="fechaActualizacionN" class="form-control" id="fechaActualizacionN" name="fechaActualizacionN" placeholder="FechaActualizacionN" value="<?php echo $row['fechaActualizacionN']; ?>" >
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="indexNomina.php" class="btn btn-default">Regresar</a>
						<button type="submit" class="btn btn-primary">Guardar</button>
					</div>
				</div>
			</form>
		</div>
	</body>
</html>