<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="">
    </head>
    <body>
    <body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Nuevo Egresos</h3>
        </div>
        <form class="form-horizontal" method="POST" action="guardarEgresos.php" autocomplete="on">
            <div class="form-group">
                <label for="idHonorarios1" class="col-sm-2 control-label">idHonorarios1</label>
                <div class="col-sm-10">
                    <input type="idHonorarios1" class="form-control" id="idHonorarios1" name="idHonorarios1" placeholder="idHonorarios1" required>
                </div>
            </div>

            <div class="form-group">
                <label for="idNomina1" class="col-sm-2 control-label">idNomina1</label>
                <div class="col-sm-10">
                    <input type="idNomina1" class="form-control" id="idNomina1" name="idNomina1" placeholder="idNomina1" required>
                </div>
            </div>

            <div class="form-group">
                <label for="idComprasTotales1" class="col-sm-2 control-label">idComprasTotales1</label>
                <div class="col-sm-10">
                    <input type="idComprasTotales1" class="form-control" id="idComprasTotales1" name="idComprasTotales1" placeholder="idComprasTotales1" required>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <a href="IndexEgresos.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>

        </form>

    </div>
</body>

</html>
    </body>
</html> 
