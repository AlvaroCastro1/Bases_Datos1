<?php
require 'conexion.php';

$id = $_GET['idInsumo'];
$sql = "SELECT*FROM insumos WHERE idInsumo = '$id'";
$resultado = $mysqli->query($sql);
$row=$resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Registro</h3>
        </div>

        <form class="form-horizontal" method="POST" action="updateInsumo.php" autocomplete="on">
            <div class="form-group">
                <label for="nombre" class="col-sm-2 control-label">Nombre</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" value="<?php echo $row['nombre']; ?>" required>
                </div>
            </div>
            <input type="hidden" id="idInsumo" name="idInsumo" value="<?php echo $row['idInsumo']; ?>">

            <div class="form-group">
					<label for="descripcion" class="col-sm-2 control-label">DESCRIPCION</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="descripcion" name="descripcion" value="<?php echo $row['descripcion']; ?>" required required>
					</div>
				</div>

				<div class="form-group">
					<label for="tipoInsumo" class="col-sm-2 control-label">TIPO INSUMO</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="tipoInsumo" name="tipoInsumo" value="<?php echo $row['tipoInsumo']; ?>" required required>
					</div>
				</div>
                <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
            <br>

                    <a href="indexInsumo.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>
