<html lang="es">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align: center">NUEVO REGISTRO</h3>
			</div>

			<form class="form-horizontal" method="POST" action="guardarNomina.php" autocomplete="off">
				<div class="form-group">
					<label for="idNomina" class="col-sm-2 control-label">IdNomina</label>
					<div class="col-sm-10">
						<input type="int" class="form-control" id="idNomina" name="idNomina" placeholder="IdNomina" required>
					</div>
				</div>

				<div class="form-group">
					<label for="idPago1" class="col-sm-2 control-label">IdPago1</label>
					<div class="col-sm-10">
						<input type="idPago1" class="form-control" id="idPago1" name="idPago1" placeholder="IdPago1" required>
					</div>
				</div>

				<div class="form-group">
					<label for="numCunetaNomina" class="col-sm-2 control-label">NumCunetaNomina</label>
					<div class="col-sm-10">
						<input type="numCunetaNomina" class="form-control" id="numCunetaNomina" name="numCunetaNomina" placeholder="NumCunetaNomina" required>
					</div>
				</div>

				<div class="form-group">
					<label for="banco" class="col-sm-2 control-label">Banco</label>
					<div class="col-sm-10">
						<input type="banco" class="form-control" id="banco" name="banco" placeholder="Banco" required>
					</div>
				</div>

				<div class="form-group">
					<label for="montoDisponible" class="col-sm-2 control-label">MontoDisponible</label>
					<div class="col-sm-10">
						<input type="montoDisponible" class="form-control" id="montoDisponible" name="montoDisponible" placeholder="MontoDisponible" required>
					</div>
				</div>

				<div class="form-group">
					<label for="fechaActualizacionN" class="col-sm-2 control-label">FechaActualizacionN</label>
					<div class="col-sm-10">
						<input type="fechaActualizacionN" class="form-control" id="fechaActualizacionN" name="fechaActualizacionN" placeholder="FechaActualizacionN" required>
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="indexNomina.php" class="btn btn-default">Regresar</a>
						<button type="submit" class="btn btn-primary">Guardar</button>
					</div>
				</div>
			</form>
		</div>
	</body>
</html>