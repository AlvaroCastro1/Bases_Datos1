<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="">
    </head>
    <body>
    <body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Nuevo Registro</h3>
        </div>
        <form class="form-horizontal" method="POST" action="GuardarCompra.php" autocomplete="on">
            <div class="form-group">
                <label for="fecha" class="col-sm-2 control-label">Fecha</label>
                <div class="col-sm-10">
                    <input type="fecha" class="form-control" id="fecha" name="fecha" placeholder="fecha" required>
                </div>
            </div>

            <div class="form-group">
                <label for="subtotal" class="col-sm-2 control-label">Subtotal</label>
                <div class="col-sm-10">
                    <input type="subtotal" class="form-control" id="subtotal" name="subtotal" placeholder="subtotal" required>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <a href="IndexCompra.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>

        </form>

    </div>
</body>

</html>
    </body>
</html> 