<?php
require 'conexion.php';
$id = $_GET['id'];
$sql = "Select * from FacturaVenta where idFacturaVenta = '$id'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Registro</h3>
        </div>

        <form class="form-horizontal" method="POST" action="updateFacturaventa.php" autocomplete="on">
            <div class="form-group">
                <label for="idDetalleVentas1" class="col-sm-2 control-label">idDetalleVentas1</label>
                <div class="col-sm-10">
                    <input type="int" class="form-control" id="idDetalleVentas1" name="idDetalleVentas1" value="<?php echo $row['idDetalleVentas1']; ?>">
                </div>
            </div>
            <input type="hidden" id="id" name="id" value="<?php echo $row['idFacturaVenta']; ?>">


            <div class="form-group">
                <label for="fechaEmisionV" class="col-sm-2 control-label">fecha Emision V</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" id="fechaEmisionV" name="fechaEmisionV" value="<?php echo $row['fechaEmisionV']; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="lugarEmisionV" class="col-sm-2 control-label">lugar Emision V</label>
                <div class="col-sm-10">
                    <input type="lugarEmisionV" class="form-control" id="lugarEmisionV" name="lugarEmisionV" placeholder="lugarEmisionV" value="<?php echo $row['lugarEmisionV']; ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <br>

                    <a href="indexFacturaventa.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>