<?php
require 'conexion.php';
$id = $_POST['idProceso'];
$tipo = $_POST['tipoProceso'];
$descripcion = $_POST['descripcionProceso'];



    $sql = "UPDATE proceso SET idProceso='$id', tipoProceso='$tipo', descripcionProceso='$descripcion' WHERE idProceso = '$id'";
    $resultado = $mysqli->query($sql);

?>

<html lang="es">
    <head>
        <meta name="vieport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/jquery-3.1.1.min.js"></script>
    </head>

    <body>
        <div class="contrainer">
            <div class="row">
                <div class="row"  style="text-aLign:center">
                <?php if($resultado) { ?>
                <h3>REGISTRO DEL PROCESO MODIFICADO</h3>
                <?php } else { ?>
                <h3>ERROR AL MODIFICAR EL PROCESO</h3>
                <?php } ?>

                <a  href="indexProceso.php" class="btn btn-primary">REGRESAR</a>

                </div>
            </div>
        </div>
    </body>
</html>
