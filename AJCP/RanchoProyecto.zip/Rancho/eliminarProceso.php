<?php
    require 'conexion.php';
    $idproceso = $_GET['idProceso'];

$sql = "DELETE FROM proceso WHERE idProceso = '$idproceso'";
$resultado = $mysqli->query($sql);
?>

<html lang="es">
    <head>
        <meta name="viewport" content="width=device-width", initial-scale="6">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/jquery-3.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <div>
            <div class="row">
                <div class="col" style="text-align: center">
                    <?php if($sql){ ?>
                    <h3>PROCESO ELIMINADO</h3>
                    <?php } else {?>
                        <h3>ERROR AL ELIMINAR EL PROCESO</h3>
                    <?php } ?>

                    <a href="indexProceso.php" class="btn btn-primary">Regresar</a>
                </div>
            </div>
        </div>
    </body>
</html>