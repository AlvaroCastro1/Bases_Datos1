<?php
    require 'conexion.php';
   
    $idEmpleado1=$_POST['idEmpleado1'];
    $falta= isset($_POST['falta'])? $_POST['falta']:0;
    $asistencia= isset($_POST['asistencia'])? $_POST['asistencia']:0;
    $horasExtra=$_POST ['horasExtra'];
    $fechaA=$_POST ['fechaA'];
    
    $sql = "INSERT INTO Asistencia(idEmpleado1, falta, asistencia, horasExtra, fechaA) VALUES ('$idEmpleado1', '$falta', '$asistencia', '$horasExtra', '$fechaA')";
    $resultado = $mysqli->query($sql);
?>
<html lang="es">
    <head>
        <meta name="viewport" content="width=devise-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/jquery-3.1.1.min.js"></script>
        <script src="js/bootstrao.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="row" style="text-align:center">
            <?php if($resultado){?>
                <h3>Registro de Asistencia Guardado</h3>
                <?php } else { ?>
                    <h3>Error al Guardar Asistencia</h3>
                <?php } ?>
                <a href="InicioAsistencia.php" class="btn btn-primary">Regresar</a>
             </div>
          </div>
       </div>
     </div>
   </body>
</html> 
