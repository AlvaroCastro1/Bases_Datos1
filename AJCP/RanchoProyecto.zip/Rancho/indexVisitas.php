<?php
	require 'Conexion.php';
	$where = "";
	if(!empty($_POST))
	{
		$valor = $_POST['campo'];
		if(!empty($valor)){
			$where = "WHERE idServicio1 LIKE '%$valor'";
		}
	}
	$sql = "SELECT * FROM Visitas $where";
	$resultado = $mysqli->query($sql);

?>

<html lang="es">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>

	<body>

		<div class='container'>
			<div class="row">
				<h2 style="text-align:center;">Rancho</h2>
			</div>

			<div class="row">
				<a href="nuevoVisitas.php" class="btn btn-primary">Nuevo Registro</a>

				<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
					<b>Id del servicio: </b><input type="text" id="campo" name="campo" />
					<input type="submit" id="enviar" name="enviar" value="Buscar" class="btn btn-info" />
				</form>
			</div>

			<br>

			<div class="row table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>IdVisitas</th>
							<th>IdServicio1</th>
							<th>Servicio</th>
							<th>FechaServicioI</th>
							<th>FechaServicioF</th>
							<th>PagoServicio</th>
							<th></th>
							<th></th>
						</tr>
					</thead>

					<tbody>
						<?php while ($row = $resultado->fetch_array(MYSQLI_ASSOC)) { ?>
							<tr>
								<td><?php echo $row['idVisitas']; ?></td>
								<td><?php echo $row['idServicio1']; ?></td>
								<td><?php echo $row['servicio']; ?></td>
								<td><?php echo $row['fechaServicioI']; ?></td>
								<td><?php echo $row['fechaServicioF']; ?></td>
								<td><?php echo $row['pagoServicio']; ?></td>
								<td><a href="modificarVisitas.php?id=<?php echo $row['idVisitas']; ?>"><span class="glyphicon glyphicon-pencil"></span></a></td>
								<td><a href="eliminarVisitas.php?id=<?php echo $row['idVisitas']; ?>"><span class="glyphicon glyphicon-trash"></span>
                                </a></td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>

		
	</body>
</html>



