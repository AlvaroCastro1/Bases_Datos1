<?php
 	require 'Conexion.php'; 
 	$where= "";
	if(!empty($_POST)){
		$valor=$_POST['campo'];
		if(!empty($valor)){
			$where="WHERE idDetalleProduccion LIKE'%$valor'";
		}
	}
	$sql="SELECT * FROM DetalleProduccion $where";
	$resultado=$mysqli->query($sql);

?>


<html lang="es">
<head>
	<meta name= "viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-theme.css" rel="stylesheet">
	<script src="js/jquery-3.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>

<body>
	<div class="container">
		<div class= "row">
			<h2 style="text-align: center">	DETALLE PRODUCCION </h2>
		</div>

		<div class="row">
			<a href="nuevoDetalleProduccion.php" class="btn btn-primary"> Nuevo Registro </a>
			<form action= "<?php $_SERVER['PHP_SELF']; ?>" method="POST">
				<b> Id Detalle de Produccion: </b><input type="text" id="campo" name="campo"/>
				<input type="submit" id="enviar" value="Buscar" class="btn btn-info" />
			</form>
		</div>

		<br>
		<div class="row table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Id Detalle Produccion</th>
						<th>Id Produccion</th>
						<th>Id Proceso </th>
						<th></th>
						<th></th>
					</tr>
				</thead>

				<tbody>
					<?php while ($row= $resultado->fetch_array(MYSQLI_ASSOC)){ ?>
						<tr>
							<td> <?php echo $row['idDetalleProduccion']; ?> </td>
							<td> <?php echo $row['idProduccion']; ?></td>
							<td> <?php echo $row['idProceso']; ?></td>
							<td> <a href="modificarDetalleProduccion.php?id=<?php echo $row['idDetalleProduccion']; ?>"><span class="=glyphicon glyphicon-pencil"></span></a></td>
							<td> <a href="eliminarDetalleProduccion.php?id=<?php echo $row['idDetalleProduccion'];?> "> <span class="glyphicon glyphicon-trash"> </span> </a> </td>
						</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>


	<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> 
					<h4 class="modal-title" id="myModalLabel">ELIMINAR REGISTRO </h4>
				</div>
				<div class="modal-body"> 
					¿Desea eliminar este registro?
				</div>

				<div class="modal-footer"> 
					<button type="button" class="btn btn-default" data-dismiss="modal"> CANCELAR </button>

					<a class="btn btn-danger btn-ok"> BORRAR </a>
				</div>
			</div>
		</div>
	</div>
</body>
</html>