<?php 
require 'Conexion.php';
$id = $_GET['idBodega'];
$sql = "select * from Bodega where idBodega = '$id'"; 
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
 ?>

 <html lang="es"><!-- inicia html-->
 <head>
 	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<link href="css/bootstrap.min.css" rel="stylesheet">
 	<link href="css/bootstrap-theme.min.css " rel="stylesheet">
 	<script src="js/jquery-3.1.1.min.js"></script>
 	<script src="js/bootstrap.min.js"></script>
 </head>

 <body>
 	<div class="container">
 		<div class="row">
 			<h3 style="text-align: center;">MODIFICAR REGISTRO</h3><!-- linea de texto-->
 		</div>
 		<form class="form-horizontal" method="POST" action="updateBodega.php" autocomplete="off"><!-- -->
 			<div class="form-group">
 				<label for="nombre" class="col-sm-2 control-label"></label>
 				<div class="col-sm-10">
 					<input type="text" class="form-control" id="cantidad" name="cantidad" placeholder="Cantidad" value= "<?php echo $row['cantidadB']; ?>" required>
 				</div>
 			</div>
 			<input type="hidden" id="id" name="id" value="<?php echo $row['idBodega']; ?>"/>
 			
 			<div class="form-group">
 				<label for="fecha" class="col-sm-2 control-label">Fecha</label>
 				<div class="col-sm-10">
 					<input type="text" class="form-control" id="fecha" name="fecha" placeholder="Fecha" value= "<?php echo $row['fechaActualizadaB']; ?>" required>
 				</div>
 			</div>
 			<div class="form-group">
 				<div class="col-sm-offset-2 col-sm-10">
 					<a href="indexBodega.php" class="btn btn-default">Regresar</a>
 					<button type="submit" class="btn btn-primary">Guardar</button>
 				</div>
 			</div>
 		</form>
 	</div>
 </body>
 </html>