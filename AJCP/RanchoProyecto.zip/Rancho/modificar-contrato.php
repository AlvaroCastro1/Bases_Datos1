<!--DIEGO GOMEZ TAGLE GONZALEZ-->
<?php
	require 'Conexion.php';
	$id= $_GET['id'];
	$sql ="SELECT*FROM Contrato WHERE idContrato='$id'";
	$resultado=$mysqli->query($sql);
	$row=$resultado->fetch_array(MYSQLI_ASSOC);

		$query=mysqli_query($mysqli,"SELECT idDepartamento,nombreDepartanmento FROM Departamento");
	$query1=mysqli_query($mysqli,"SELECT idCargo,nombreCargo FROM Cargo");

?>

<html lang="es">
	<head>
		<meta name= "viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align:center">MODIFICAR REGISTRO</h3>
			</div>
			<form class="form-horizontal" method="POST" action="update-contrato.php" autocomplete="off">
				<div class="form-group">
					<label for="idContrato" class="col-sm-2 control-label">ID CONTRATO</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="idContrato" name="idContrato" placeholder="IdContrato" value="<?php echo $row['idContrato']; ?>" required>
					</div>
				</div>
				<div class="form-group">
					<label for="idDepartamento" class="col-sm-2 control-label">DEPARTAMENTO</label>
						<div class="col-sm-10">
							<select class="form-control" id="idDepartamento" name="idDepartamento">
								<?php while ($datos=mysqli_fetch_array($query)) 
									{
								?>
								<option value="<?php echo $datos['idDepartamento']?>"><?php echo $datos['nombreDepartanmento']?></option>
								<?php
									}
								?>
							</select>
						</div>
				</div>
				<div class="form-group">
					<label for="idCargo" class="col-sm-2 control-label">CARGO</label>
						<div class="col-sm-10">
							<select class="form-control" id="idCargo" name="idCargo">
								<?php while ($datos1=mysqli_fetch_array($query1)) 
									{
								?>
								<option value="<?php echo $datos1['idCargo']?>"><?php echo $datos1['nombreCargo']?></option>
								<?php
									}
								?>
							</select>
						</div>
				</div>


				<div class="form-group">
					<label for="sueldo" class="col-sm-2 control-label">SUELDO</label>
					<div class="col-sm-10">
						<input type="int" class="form-control" id="sueldo" name="sueldo" value="<?php echo $row['sueldo']; ?>" >
					</div>
				</div>
				<div class="form-group">
					<label for="inicioContrato" class="col-sm-2 control-label">INICIO CONTRATO</label>
					<div class="col-sm-10">
						<input type="date" class="form-control" id="inicioContrato" name="inicioContrato" value="<?php echo $row['inicioContrato']; ?>">
					</div>
				</div>

				<div class="form-group">
					<label for="finalContrato" class="col-sm-2 control-label">FINAL CONTRATO</label>
					<div class="col-sm-10">
						<input type="date" class="form-control" id="finalContrato" name="finalContrato" value="<?php echo $row['finalContrato']; ?>">
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="index-contrato.php" class="btn btn-default">regresar </a>
						<button type="submit" class="btn btn-primary">Guardar </button>	
					</div>
				</div>
			</form>
		</div>
	</body>
</html>