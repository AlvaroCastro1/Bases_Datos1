<?php
//se conecta a la base de datos
require 'conexion.php';
//se le da valor a cada una de las variables
$idStock1 = $_POST['idStock1'];
$nombreProducto = $_POST['nombreProducto'];
$precioProducto = $_POST['precioProducto'];
$tipoUnidad = $_POST['tipoUnidad'];
$cantidad = $_POST['cantidad'];
$descripcion = $_POST['descripcion'];


//se insertan los valores a la base de datos
$sql = "INSERT INTO Producto (idStock1, nombreProducto, precioProducto, tipoUnidad, cantidad, descripcion) VALUES(
            '$idStock1', '$nombreProducto', '$precioProducto', '$tipoUnidad', '$cantidad', '$descripcion')";

$resultado = $mysqli->query($sql);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="row" style="text-align:center">
                <!--se crea un metodo para ver si se guardo bien o no-->
                <?php if ($resultado) { ?>
                    <h3>Registro Guardado</h3>
                <?php } else { ?>
                    <h3>Error al Guardar</h3>
                <?php } ?>
                <!--se da la opcion de regresar-->
                <a href="indexProducto.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>

    </div>
</body>

</html>
