<html lang="es">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="">
    </head>
    <body>
    <body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Nuevo Registro Lote</h3>
        </div>
        <form class="form-horizontal" method="POST" action="guardarLote.php" autocomplete="on">
            <div class="form-group">
                <label for="fechaE" class="col-sm-2 control-label">Fecha empaquetado</label>
                <div class="col-sm-10">
                <input type="date" class="form-control" id="fechaE" name="fechaE" required>
                </div>
            </div>

            <div class="form-group">
                <label for="fechaC" class="col-sm-2 control-label">Fecha Caducidad</label>
                <div class="col-sm-10">
                <input type="date" class="form-control" id="fechaC" name="fechaC" required>
                </div>
            </div>

            <div class="form-group">
                <label for="ambiente" class="col-sm-2 control-label">Tipo Ambiente</label>
                <div class="col-sm-10">
                    <input type="ambiente" class="form-control" id="ambiente" name="ambiente" placeholder="Ambiente" required>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <a href="indexLote.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>

        </form>

    </div>
</body>

</html>
    </body>
</html> 

