<html lang="es">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/query-3.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>

    <body>
        <div class="container">
            <div class="row">
                <div class="col">
                    <h3 style="text-align:center">NUEVO PROCESO</h3>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <form class="form-horizontal" method="POST" action="guardarProceso.php" autocomplete="off">
                        <div class="form-group row">
                            <label for="idProceso" class="col-sm-2 control-label">ID</label>
                            <div class="col-sm-10">
                                <input  type="number" class="form-control" id="idProceso" name="idProceso" 
                                placeholder="ID" required>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="email" class="col-sm-2 control-label">TIPO DE PROCESO</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="tipoProceso" name="tipoProceso" placeholder="TIPO DE PROCESO" 
                                required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="telefono" class="col-sm-2 control-label">DESCRIPCION</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="descripcionProceso" name="descripcionProceso" placeholder="DESCRIPCION">
                            </div>    
                        </div>

                        

                        <div class="form-group row">
                            <div class="col-sm-offset-2 col-sm-10">
                                <a href="indexProceso.php" class="btn btn-defauult">Regresar</a>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>