<?php
    require 'conexion.php';
    $where = "";
    if (!empty($_POST)) 
    {
        $valor = $_POST['campo'];
        if (!empty($valor)) {
            $where = "WHERE idEmpleado1 LIKE'%$valor'";
        }
    }
    $sql = "SELECT * FROM Asistencia $where";
    $resultado = $mysqli->query($sql);

?>

<html lang="es">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    
    <div class="container">
        <div class="row">
            <!--Texto alineado al centro que forma el titulo de la pagina -->
            <h2 style="text-align: center">Rancho registro de asistencias</h2>
        </div>

        <div class="row">
            <!-- "Nuevo registro se declara como boton primario" -->
            <a href="asistencia.php" class="btn btn-primary">Nuevo Registro de Asistencia</a>

            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                <b>id Empleado: </b><input type="int" id="campo" name="campo" />
                <input type="submit" id="enviar" name="enviar" value="Buscar" class="btn btn-info" />
            </form>

        </div>

        <br>
        <div class="row table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Id de Asistencia</th>
                        <th>Id del empleado</th>
                        <th>Asistió</th>
                        <th>Faltó</th>
                        <th>Horas extras de trabajo</th>
                        <th>Fecha</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    <?php while ($row = $resultado->fetch_array(MYSQLI_ASSOC)) { ?>
                        <tr>
                            <td>
                                <?php echo $row['idAsistencia']; ?>
                            </td>
                            <td>
                                <?php echo $row['idEmpleado1']; ?>
                            </td>
                            <td>
                                <?php echo $row['falta']; ?>
                            </td>
                            <td>
                                <?php echo $row['asistencia']; ?>
                            </td>
                            <td>
                                <?php echo $row['horasExtra']; ?>
                            </td>
                            <td>
                                <?php echo $row['fechaA']; ?>
                            </td>
                            <td>
                                <a href="ModificarAsistencia.php?id=<?php echo $row['idEmpleado1']; ?>">
                                    <span class="glyphicon glyphicon-pencil"></span></a>
                            </td>
                            <td>
                                <a href="EliminarAsistencia.php?id=<?php echo $row['idEmpleado1']; ?>"><span class="glyphicon glyphicon-trash"></span>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>>