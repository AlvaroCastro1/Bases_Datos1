<?php

	require 'Conexion.php';

	$idVisitas = $_POST['idVisitas'];
	$idServicio1 = $_POST['idServicio1'];
	$servicio = $_POST['servicio'];
	$fechaServicioI = $_POST['fechaServicioI'];
	$fechaServicioF = $_POST['fechaServicioF'];
	$pagoServicio = $_POST['pagoServicio'];

	$sql = "UPDATE Visitas SET idVisitas='$idVisitas', idServicio1='$idServicio1', servicio='$servicio', fechaServicioI ='$fechaServicioI', fechaServicioF='fechaServicioF', pagoServicio='$pagoServicio' WHERE idVisitas = '$idVisitas'";
	$resultado = $mysqli->query($sql);


?>

<html lang="es">
	<head>

		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<div class="row" style="text-align: center">
				<?php if($resultado){ ?>
				<h3>REGISTRO MODIFICADO</h3>
				<?php } else { ?>
				<h3>ERROR AL MODIFICAR</h3>
				<?php } ?>

				<a href="indexVisitas.php" class="btn btn-primary">Regresar</a>

				</div>
			</div>
		</div>
	</body>
</html>