<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="">
    </head>
    <body>
    <body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Nuevo Registro</h3>
        </div>
        <form class="form-horizontal" method="POST" action="guardarCargo.php" autocomplete="on">
            <div class="form-group">
                <label for="idJornada1" class="col-sm-2 control-label">id de la Jornada</label>
                <div class="col-sm-10">
                    <input type="idJornada1" class="form-control" id="idJornada1" name="idJornada1" placeholder="id de la Jornada" required>
                </div>
            </div>

            <div class="form-group">
                <label for="nombreCargo" class="col-sm-2 control-label">Cargo</label>
                <div class="col-sm-10">
                    <input type="nombreCargo" class="form-control" id="nombreCargo" name="nombreCargo" placeholder="Cargo" required>
                </div>
            </div>

            <div class="form-group">
                <label for="descripcion" class="col-sm-2 control-label">Descripcion</label>
                <div class="col-sm-10">
                    <input type="descripcion" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion" required>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <a href="indexCargo.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>

        </form>

    </div>
</body>

</html>
    </body>
</html>
