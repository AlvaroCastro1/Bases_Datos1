<?php
    require 'conexion.php';

    $where = "";

    if (!empty($_POST))
    {
    $valor = $_POST['campo'];
    if (!empty($valor)) {
        $where = "WHERE nombreProducto LIKE'%$valor'";
    }
}
    //da a conocer la tabala doctor de la base de datos
    $sql = "SELECT * FROM Producto $where";
    $resultado = $mysqli->query($sql);

?>
<html lang="es">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>

    <div class="container">
        <div class="row">
            <!--Se muestra un texto en pantalla-->
            <h2 style="text-align: center">Conexion de PHP Y MYSQL</h2>
        </div>

        <div class="row">
            <a href="nuevoProducto.php" class="btn btn-primary">Nuevo Registro</a>
                <!--se realiza la accion guardar con los elementos indicados-->
            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                <b>Nombre: </b><input type="text" id="campo" name="campo" />
                <input type="submit" id="enviar" name="enviar" value="Buscar" class="btn btn-info" />
            </form>
        </div>

        <br>
        <div class="row table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <!--Se crea una tabla con tipo de dato que estaran-->
                        <th>ID</th>
                        <th>Stock</th>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Unidad</th>
                        <th>Cantida</th>
                        <th>Descripcion</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    <?php while ($row = $resultado->fetch_array(MYSQLI_ASSOC)) { ?>
                        <tr>
                            <td>
                                <?php echo $row['idProducto']; ?>
                            </td>
                            <td>
                                <?php echo $row['idStock1']; ?>
                            </td>
                            <td>
                                <?php echo $row['nombreProducto']; ?>
                            </td>
                            <td>
                                <?php echo $row['precioProducto']; ?>
                            </td>
                            <td>
                                <?php echo $row['tipoUnidad']; ?>
                            </td>
                            <td>
                                <?php echo $row['cantidad']; ?>
                            </td>
                            <td>
                                <?php echo $row['descripcion']; ?>
                            </td>
                            <td>
                                <!--Se determina respecto que se va a modificar el registro-->
                                <a href="modificarProducto.php?idProducto=<?php echo $row['idProducto']; ?>">
                                    <span class="glyphicon glyphicon-pencil"></span></a>
                            </td>
                            <td>
                                <!--Se determina respecto a que medio se va a eliminar el registro-->
                                <a href="eliminarProducto.php?idProducto=<?php echo $row['idProducto']; ?>"><span class="glyphicon glyphicon-trash"></span>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>


    <!--Modal-->
<!--     <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dimiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">ELIMINAR REGISTRO </h4>
                </div>
                <div class="modal-body">
                    ¿Desea eliminar este registro?
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dimiss="modal">Cancel </button>
                    <a class="btn btn-danger btn-ok">:(</a>
                </div>
            </div>
        </div>
    </div> -->
</body>

</html>>
