<?php
	include 'Conexion.php';
	
	$query=mysqli_query($mysqli,"SELECT idProduccion FROM Produccion");
	$query1=mysqli_query($mysqli,"SELECT idProceso FROM Proceso");

?>

<html lang="es">
	<head>
		<meta name= "viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align: center"> NUEVO REGISTRO </h3>

			</div>
			<form class="form-horizontal" method="POST" action="guardarDetalleProduccion.php" autocomplete="off">
				<div class="form-group">
					<label for="idDetalleProduccion" class="col-sm-2 control-label">ID DETALLE PRODUCCION</label>
					<div class="col-sm-10">

						<input type="float" class="form-control" id="idDetalleProduccion" name="idDetalleProduccion" placeholder="idDetalleProduccion" required>
					</div>
				</div>

				<div class="form-group">
					<label for="idProduccion" class="col-sm-2 control-label">ID PRODUCCION</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="idProduccion" name="idProduccion" placeholder="idProduccion" required>
					</div>
				</div>


				<div class="form-group">
					<label for="idProceso" class="col-sm-2 control-label">ID PROCESO</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="idProceso" name="idProceso" placeholder="idProceso" required>
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="indexDetalleProduccion.php" class="btn btn-default"> Regresar </a>
						<button type="submit" class="btn btn-primary"> Guardar </button>	
					</div>
				</div>
			</form>
		</div>
	</body>
</html>