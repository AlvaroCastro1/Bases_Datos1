<?php
require 'Conexion.php';
    $idVisitas2=$_POST['idVisitas2'];
	$fechaEmisionH = $_POST['fechaEmisionH'];
    $fechaVencimientoH = $_POST['fechaVencimientoH'];
    $lugarEmisionH = $_POST['lugarEmisionH'];
    $lugarVencimientoH = $_POST['lugarVencimientoH'];
            $sql = "INSERT INTO FacturaHonorarios (idVisitas2, fechaEmisionH, fechaVencimientoH, lugarEmisionH, lugarVencimientoH ) VALUES(
            '$idVisitas2','$fechaEmisionH', '$fechaVencimientoH', '$lugarEmisionH', '$lugarVencimientoH')";
$resultado = $mysqli->query($sql);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="row" style="text-align:center">
                <?php if ($resultado) { ?>
                    <h3>Registro Guardado</h3>
                <?php } else { ?>
                    <h3>Error al Guardar</h3>
                <?php } ?>
                <a href="IndexFH.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>

    </div>
</body>

</html>