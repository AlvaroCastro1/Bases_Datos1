<?php
//se conecta a la base de datos
require 'conexion.php';
//se les da valores a las variables
$idProducto = $_GET['idProducto'];
//se determina el proceso que se realizara
$sql = "Select * from Producto where idProducto = '$idProducto'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Producto</h3>
        </div>

        <form class="form-horizontal" method="POST" action="updateProducto.php" autocomplete="on">
            <div class="form-group">
                <!--se asigna el cambio de valor al nombre-->
                <label for="idStock1" class="col-sm-2 control-label">id del Stock</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="idStock1" name="idStock1" placeholder="idStock1" value="<?php echo $row['idStock1']; ?>" required>
                </div>
            </div>
            <input type="hidden" id="idProducto" name="idProducto" value="<?php echo $row['idProducto']; ?>">

            <div class="form-group">
                <!--se asigna el cambio de valor al email-->
                <label for="email" class="col-sm-2 control-label">Nombre</label>
                <div class="col-sm-10">
                    <input type="nombreProducto" class="form-control" id="nombreProducto" name="nombreProducto" placeholder="nombreProducto" value="<?php echo $row['nombreProducto']; ?>">
                </div>
            </div>

            <div class="form-group">
                <!--se asigna el cambio de valor al telefono-->
                <label for="precioProducto" class="col-sm-2 control-label">Precio</label>
                <div class="col-sm-10">
                    <input type="precioProducto" class="form-control" id="precioProducto" name="precioProducto" placeholder="Precio" value="<?php echo $row['precioProducto']; ?>">
                </div>
            </div>

            <div class="form-group">
                <!--se asigna el cambio de valor a la universidad-->
                <label for="tipoUnidad" class="col-sm-2 control-label">Tipo de unidad</label>
                <div class="col-sm-10">
                    <select class="form-control" id="tipoUnidad" name="tipoUnidad">
                        <option value="kilogramo" <?php if ($row['tipoUnidad'] == 'kilogramo') echo 'selected'; ?>>kilogramo</option>
                        <option value="gramo" <?php if ($row['tipoUnidad'] == 'gramo') echo 'selected'; ?>>gramo</option>
                        <option value="litro" <?php if ($row['tipoUnidad'] == 'litro') echo 'selected'; ?>>Litro</option>
                        <option value="mililitro" <?php if ($row['tipoUnidad'] == 'mililitro') echo 'selected'; ?>>mililitro</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <!--se asigna el cambio de valor al telefono-->
                <label for="cantidad" class="col-sm-2 control-label">Cantidad</label>
                <div class="col-sm-10">
                    <input type="cantidad" class="form-control" id="cantidad" name="cantidad" placeholder="Cantidad" value="<?php echo $row['cantidad']; ?>">
                </div>
            </div>

            <div class="form-group">
                <!--se asigna el cambio de valor al telefono-->
                <label for="descripcion" class="col-sm-2 control-label">Descripcion</label>
                <div class="col-sm-10">
                    <input type="descripcion" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion" value="<?php echo $row['descripcion']; ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
            <br>
                    <!--se da la opcion de guardar o de regresar-->
                    <a href="indexProducto.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>
