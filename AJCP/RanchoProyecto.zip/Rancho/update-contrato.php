<!--DIEGO GOMEZ TAGLE GONZALEZ-->
<?php
		require 'Conexion.php';

	$idContrato=$_POST['idContrato'];
	$idDepartamento1=$_POST['idDepartamento'];
	$idCargo1=$_POST['idCargo'];
	$sueldo=$_POST['sueldo'];
	$inicioContrato=$_POST['inicioContrato'];
	$finalContrato=$_POST['finalContrato'];
		
		$sql="UPDATE Contrato SET idContrato='$idContrato',idDepartamento1='$idDepartamento1',idCargo1='$idCargo1',sueldo='$sueldo',inicioContrato='$inicioContrato',finalContrato='$finalContrato'WHERE idContrato='$idContrato'";	
		$resultado=$mysqli->query($sql);
?>

<html lang="es">
	<head>
		<meta name= "viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="row" style="text-align: center">
				<?php if($resultado){ ?>
				<h3>REGISTRO MODIFICADO </h3>
				<?php } else{ ?>
				<h3>ERROR AL MODIFICAR</h3>
				<?php } ?>

			<a href="index-contrato.php" class="btn btn.primary">Regresar</a>
				</div>
			</div>
		</div>
	</body>
</html>