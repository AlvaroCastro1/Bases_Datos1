<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="">
    </head>
    <body>
    <body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Nuevo Registro</h3>
        </div>
        <form class="form-horizontal" method="POST" action="GuardarProv.php" autocomplete="on">
            <div class="form-group">
                <label for="razonSocial" class="col-sm-2 control-label">Razon Social</label>
                <div class="col-sm-10">
                    <input type="razonSocial" class="form-control" id="razonSocial" name="razonSocial" placeholder="razonSocial" required>
                </div>
            </div>

            <div class="form-group">
                <label for="estado" class="col-sm-2 control-label">Estado</label>
                <div class="col-sm-10">
                    <input type="estado" class="form-control" id="estado" name="estado" placeholder="estado" required>
                </div>
            </div>

            <div class="form-group">
                <label for="municipio" class="col-sm-2 control-label">Municipio</label>
                <div class="col-sm-10">
                    <input type="municipio" class="form-control" id="municipio" name="municipio" placeholder="municipio" required>
                </div>
            </div>
            
             <div class="form-group">
                <label for="colonia" class="col-sm-2 control-label">Colonia</label>
                <div class="col-sm-10">
                    <input type="colonia" class="form-control" id="colonia" name="colonia" placeholder="colonia" required>
                </div>
            </div>
            
             <div class="form-group">
                <label for="calle" class="col-sm-2 control-label">Calle</label>
                <div class="col-sm-10">
                    <input type="calle" class="form-control" id="calle" name="calle" placeholder="calle" required>
                </div>
            </div>
            
             <div class="form-group">
                <label for="numExt" class="col-sm-2 control-label">Numero Exterior</label>
                <div class="col-sm-10">
                    <input type="numExt" class="form-control" id="numExt" name="numExt" placeholder="numExt" required>
                </div>
            </div>
           
             <div class="form-group">
                <label for="numInt" class="col-sm-2 control-label">Numero Interior</label>
                <div class="col-sm-10">
                    <input type="numInt" class="form-control" id="numInt" name="numInt" placeholder="numInt" required>
                </div>
            </div>
            
             <div class="form-group">
                <label for="CP" class="col-sm-2 control-label">CP</label>
                <div class="col-sm-10">
                    <input type="CP" class="form-control" id="CP" name="CP" placeholder="CP" required>
                </div>
            </div>
            
             <div class="form-group">
                <label for="telefono" class="col-sm-2 control-label">Telefono</label>
                <div class="col-sm-10">
                    <input type="tel" class="form-control" id="telefono" name="telefono" placeholder="telefono" required>
                </div>
            </div>
            
             <div class="form-group">
                <label for="correo" class="col-sm-2 control-label">Correo</label>
                <div class="col-sm-10">
                    <input type="correo" class="form-control" id="correo" name="correo" placeholder="correo" required>
                </div>
            </div>


            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <a href="IndexProv.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>

        </form>

    </div>
</body>

</html>
    </body>
</html> 
