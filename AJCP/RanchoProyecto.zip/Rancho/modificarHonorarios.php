<?php
require 'Conexion.php';
$idHonorarios = $_GET['id'];
$sql = "Select * from Honorarios where idHonorarios = '$idHonorarios'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Honorarios</h3>
        </div>

        <form class="form-horizontal" method="POST" action="UpdateHonorarios.php" autocomplete="on">
            <div class="form-group">
                <label for="idVisitas1" class="col-sm-2 control-label">idVisitas</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="idVisitas1" name="idVisitas1" placeholder="idVisitas1" value="<?php echo $row['idVisitas1']; ?>" required>
                </div>
            </div>
            <input type="hidden" id="idHonorarios" name="idHonorarios" value="<?php echo $row['idHonorarios']; ?>">

            <div class="form-group">
                <label for="idPeriodo2" class="col-sm-2 control-label">idPeriodo</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="idPeriodo2" name="idPeriodo2" placeholder="idPeriodo2" value="<?php echo $row['idPeriodo2']; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="cantidad" class="col-sm-2 control-label">cantidadTP</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="cantidadTP" name="cantidadTP" placeholder="cantidadTP" value="<?php echo $row['cantidadTP']; ?>">
                </div>
            </div>
            

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
            <br>

                    <a href="IndexHonorarios.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>