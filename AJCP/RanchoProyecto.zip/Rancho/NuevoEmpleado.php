
<html lang="es">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/query-3.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <title>Empleado Registro</title>  
    <body style="background: #bdc3c7; background: -webkit-linear-gradient(to right, #2c3e50, #bdc3c7);  background: linear-gradient(to right, #2c3e50, #bdc3c7); ">
        <div class="container" style="background-color: white">
            <div class="row">
                <div class="col">
                    <h3 style="text-align:center">NUEVO REGISTRO</h3>
                </div>
            </div>
                <div class="row">
                    <div class="col">
                        <form class="form-horizontal" method="POST" action="guardarEmpleado.php" autocomplete="off">
                            
                            <div class="form-group row">
                                <label for="nombre" class="col-sm-2 control-label">Nombre Completo</label>
                                <div class="col-sm-10">
                                    <input  type="text" class="form-control" id="nombre" name="nombre" 
                                    placeholder="Nombre Completo" required>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <label for="RFC" class="col-sm-2 control-label">RFC</label>
                                <div class="col-sm-10">
                                    <input type="RFC" class="form-control" id="RFC" name="RFC" placeholder="RFC" required>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <label for="NSS" class="col-sm-2 control-label">NSS</label>
                                <div class="col-sm-10">
                                    <input type="NSS" class="form-control" id="NSS" name="NSS" placeholder="NSS" required>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <label for="correo" class="col-sm-2 control-label">Email</label>
                                <div class="col-sm-10">
                                    <input type="correo" class="form-control" id="correo" name="correo" placeholder="Correo Electronico" required>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <label for="telefono" class="col-sm-2 control-label">Telefono</label>
                                <div class="col-sm-10">
                                    <input type="telefono" class="form-control" id="telefono" name="telefono" placeholder="Telefono" 
                                    required>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <label for="direccion" class="col-sm-2 control-label">Direccion</label>
                                <div class="col-sm-10">
                                    <input type="direccion" class="form-control" id="direccion" name="direccion" placeholder="Direccion" 
                                    required>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <label for="nocuenta_bancaria" class="col-sm-2 control-label">No de Cuenta</label>
                                <div class="col-sm-10">
                                    <input type="nocuenta_bancaria" class="form-control" id="nocuenta_bancaria" name="nocuenta_bancaria" placeholder="No de Cuenta Bancaria" 
                                    required>
                                </div>
                            </div>


                            <div class="form-group row">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <a href="indexEmpleado.php" class="btn btn-defauult">Regresar</a>
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>  
    </body>

</html>



