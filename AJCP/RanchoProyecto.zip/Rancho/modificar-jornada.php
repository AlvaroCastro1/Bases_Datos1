<!--DIEGO GOMEZ TAGLE GONZALEZ-->
<?php
	require 'conexion.php';
	$id= $_GET['id'];
	$sql ="SELECT*FROM Jornada WHERE idJornada='$id'";
	$resultado=$mysqli->query($sql);
	$row=$resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">
	<head>
		<meta name= "viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align:center">MODIFICAR REGISTRO</h3>
			</div>
			<form class="form-horizontal" method="POST" action="update-jornada.php" autocomplete="off">
				<div class="form-group">
					<label for="idJornada" class="col-sm-2 control-label">ID</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="idJornada" name="idJornada" placeholder="IdJornada" value="<?php echo $row['idJornada']; ?>" required>
					</div>
				</div>

				<div class="form-group">
					<label for="turno" class="col-sm-2 control-label">TURNO</label>
					<div class="col-sm-10">
						<select class="form-control" id= "turno" name="turno">
							<option value="MATUTINO" <?php if($row['turno']=='MATUTINO') echo 'selected'; ?>>MATUTINO</option>
							<option value="VESPERTINO" <?php if($row['turno']=='VESPERTINO') echo 'selected'; ?>>VESPERTINO</option>
							<option value="MIXTO" <?php if($row['turno']=='MIXTO') echo 'selected'; ?>>MIXTO</option>
						</select>
					</div>
				</div>


				<div class="form-group">
					<label for="horaEnt" class="col-sm-2 control-label">HORA ENTRADA</label>
					<div class="col-sm-10">
						<input type="time" class="form-control" id="horaEnt" name="horaEnt" value="<?php echo $row['horaEnt']; ?>" >
					</div>
				</div>
				<div class="form-group">
					<label for="horaSal" class="col-sm-2 control-label">HORA SALIDA</label>
					<div class="col-sm-10">
						<input type="time" class="form-control" id="horaSal" name="horaSal" value="<?php echo $row['horaSal']; ?>" >
					</div>
				</div>

				<div class="form-group">
					<label for="horaSalCom" class="col-sm-2 control-label">HORA SALIDA COMIDA</label>
					<div class="col-sm-10">
						<input type="time" class="form-control" id="horaSalCom" name="horaSalCom" value="<?php echo $row['horaSalCom']; ?>" >
					</div>
				</div>

				<div class="form-group">
					<label for="horaEntCom" class="col-sm-2 control-label">HORA ENTRADA COMIDA</label>
					<div class="col-sm-10">
						<input type="time" class="form-control" id="horaEntCom" name="horaEntCom" value="<?php echo $row['horaEntCom']; ?>" >
					</div>
				</div>

				<div class="form-group">
					<label for="diasDescanso" class="col-sm-2 control-label">DIA DE DESCANSO</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="diasDescanso" name="diasDescanso" value="<?php echo $row['diasDescanso']; ?>" >
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="index-jornada.php" class="btn btn-default">regresar </a>
						<button type="submit" class="btn btn-primary">Guardar </button>	
					</div>
				</div>
			</form>
		</div>
	</body>
</html>