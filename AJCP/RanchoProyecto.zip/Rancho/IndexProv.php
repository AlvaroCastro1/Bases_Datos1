<?php
    require 'Conexion.php';

    $where = "";
  
    if (!empty($_POST)) 
    {
    $valor = $_POST['campo'];
    if (!empty($valor)) {
        $where = "WHERE razonSocial LIKE'%$valor'";
    }
}
    //esta sentencia realiza la consulta de la tabla que se va a mostrar cuando se entre a la pagina
    $sql = "SELECT * FROM Proveedores $where";
    $resultado = $mysqli->query($sql);

?>
<html lang="es">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    
    <div class="container">
        <div class="row">
            <!--Texto alineado al centro que forma el titulo de la pagina -->
            <h2 style="text-align: center">Rancho</h2>
        </div>

        <div class="row">
            <!-- "Nuevo registro se declara como boton primario" -->
            <a href="NuevoProv.php" class="btn btn-primary">Nuevo Registro</a>

            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                <b>Nombre: </b><input type="text" id="campo" name="campo" />
                <input type="submit" id="enviar" name="enviar" value="Buscar" class="btn btn-info" />
            </form>
        </div>

        <br>
        <div class="row table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <!--Estos seran las "etiquetas" que mostraran el nombre de cada campo de la tabla -->
                        <th>ID</th>
                        <th>Razon social</th>
                        <th>Estado</th>
                        <th>Municipio</th>
                        <th>Colonia</th>
                        <th>Calle</th>
                        <th>NumExt</th>
                        <th>NumInt</th>
                        <th>CP</th>
                        <th>Telefono</th>
                        <th>Correo</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    <?php while ($row = $resultado->fetch_array(MYSQLI_ASSOC)) { ?>
                        <tr>
                            <!--Se define cuales seran las variables que se mostraran en la tabla -->
                            <td>
                                <?php echo $row['idProveedor']; ?>
                            </td>
                            <td>
                                <?php echo $row['razonSocial']; ?>
                            </td>
                            <td>
                                <?php echo $row['estado']; ?>
                            </td>
                            <td>
                                <?php echo $row['municipio']; ?>
                            </td>
                            <td>
                                <?php echo $row['colonia']; ?>
                            </td>
                            <td>
                                <?php echo $row['calle']; ?>
                            </td>
                            <td>
                                <?php echo $row['numExt']; ?>
                            </td>
                            <td>
                                <?php echo $row['numInt']; ?>
                            </td>
                            <td>
                                <?php echo $row['CP']; ?>
                            </td>
                            <td>
                                <?php echo $row['telefono']; ?>
                            </td>
                            <td>
                                <?php echo $row['correo']; ?>
                            </td>
                            <td>

                                <a href="ModificarProv.php?id=<?php echo $row['idProveedor']; ?>">
                                    <span class="glyphicon glyphicon-pencil"></span></a>
                            </td>
                            <td>

                                <a href="EliminarProv.php?id=<?php echo $row['idProveedor']; ?>"><span class="glyphicon glyphicon-trash"></span>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>>