<!--DIEGO URIEL DOMINGUEZ GUZMAN-->
<?php
	include 'conexion.php';
	$query=mysqli_query($mysqli,"SELECT idVenta FROM Venta");
	$query1=mysqli_query($mysqli,"SELECT idProducto,nombreProducto FROM Producto");
	
?>

<html lang="es">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align: center">NUEVO REGISTRO</h3>

			</div>
			<form class="form-horizontal" method="POST" action="guardar-detalleventas.php" autocomplete="off">

				<div class="form-group">
					<label for="idVenta1" class="col-sm-2 control-label">ID Venta</label>
					<div class="col-sm-10">
						<select class="form-control" id="idVenta1" name="idVenta1">
								<?php while ($datos=mysqli_fetch_array($query)) 
									{
								?>
								<option value="<?php echo $datos['idVenta']?>"><?php echo $datos['idVenta']?></option>
								<?php
									}
								?>
							</select>
					</div>
				</div>

				<div class="form-group">
					<label for="idProducto" class="col-sm-2 control-label">PRODUCTO</label>
						<div class="col-sm-10">
							<select class="form-control" id="idProducto1" name="idProducto1">
								<?php while ($datos=mysqli_fetch_array($query1)) 
									{
								?>
								<option value="<?php echo $datos['idProducto']?>"><?php echo $datos['nombreProducto']?></option>
								<?php
									}
								?>
							</select>
						</div>
				</div>

				<div class="form-group">
					<label for="cantidadNR" class="col-sm-2 control-label">CANTIDAD DE PRODUCTO</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="cantidadNR" name="cantidadNR" placeholder="cantidadNR" required>
					</div>
				</div>

				<div class="form-group">
					<label for="subtotal" class="col-sm-2 control-label">SUBTOTOTAL</label>
					<div class="col-sm-10">
						<input type="float" class="form-control" id="subtotal" name="subtotal" placeholder="subtotal" required>
					</div>
				</div>
				
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="index-detallecompra.php" class="btn btn-default">regresar </a>
						<button type="submit" class="btn btn-primary">Guardar </button>
					
					</div>
				</div>
			</form>
		</div>
	</body>
</html>