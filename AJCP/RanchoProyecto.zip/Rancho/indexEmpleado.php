<?php 
    require 'Conexion.php';
    $where = "";

    if(!empty($_POST))
    {
        $valor = $_POST['campo'];
        if(!empty($valor)){
            $where = "WHERE nombreEmpleado LIKE '%$valor'";
        }
    }
    $sql = "SELECT* FROM empleado $where";
    $resultado = $mysqli->query($sql);
    
?>

<html lang="es">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/jquery-3.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>


    </head>

    <body style="background: #b92b27;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #1565C0, #b92b27);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #1565C0, #b92b27); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
"> 
        <div class="container" style="background-color:white">
            <div class="row">
                <h2 style="text-align:center">Empleados Rancho</h2>
            </div>

            <div class="row">
                <a href="NuevoEmpleado.php" class="btn btn-primary">Nuevo Empleado</a>
                <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                <b>Nombre: </b><input type="text" id="campo" name="campo" />
                <input type="submit" id="enviar" name="enviar" value="Buscar" class="btn btn-info" />
            </form>

            </div>

            <br>
            
            <div class="row table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>RFC</th>
                            <th>NSS</th>
                            <th>Correo</th>
                            <th>Telefono</th>
                            <th>Direccion</th>
                            <th>NoCuenta</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php while($row = $resultado->fetch_array(MYSQLI_ASSOC)) { ?>
                            <tr>
                                <td><?php echo $row['idEmpleado']; ?></td>
                                <td><?php echo $row['nombreEmpleado']; ?></td>
                                <td><?php echo $row['RFC']; ?></td>
                                <td><?php echo $row['NSS']; ?></td>
                                <td><?php echo $row['correoE']; ?></td>
                                <td><?php echo $row['telefono']; ?></td>
                                <td><?php echo $row['direccion']; ?></td>
                                <td><?php echo $row['noCuentaBancaria']; ?></td>
                                <td><a href="modificarEmpleado.php?id=<?php echo $row['idEmpleado']; ?>" ><span class="glyphicon 
                                glyphicon-pencil"></span></a></td>
                                <td><a href="eliminarEmpleado.php?id=<?php echo $row['idEmpleado']; ?>" data-toggle="modal" data-target="#confirm-delete"><span class="glyphicon glyphicon-trash"></span>
                                </a></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!--Modal-->
        <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel"> Eliminar Registro</h4>
                    </div>

                    <div class="modal-body">
                        ¿Desea Eliminar este Registro?
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-defualt" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-danger btn-ok">Delete</a>
                    </div>
                </div>
            </div>
        </div>

    </body>
</html>