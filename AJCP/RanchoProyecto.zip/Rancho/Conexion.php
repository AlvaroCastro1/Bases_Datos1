<?php

$mysqli = new mysqli('localhost', 'root', '', 'rancho');
if ($mysqli -> connect_error) {
    die('No se pudo conectar a la base de datos');
}

?>