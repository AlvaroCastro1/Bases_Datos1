<?php 
require 'conexion.php';

$id = $_POST['id'];
$cantidad = $_POST['cantidad'];
$fecha = $_POST['fecha'];
$sql = "update Bodega set cantidadB = '$cantidad', fechaActualizadaB = '$fecha' where idBodega ='$id'";
$resultado = $mysqli->query($sql);

 ?>
 <!DOCTYPE html><!-- se inicaliza html-->
 <html lang="es">
 <head>
 	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 		<link href="css/bootstrap.min.css" rel="stylesheet">
 	<link href="css/bootstrap-theme.min.css " rel="stylesheet">
 	<script src="js/jquery-3.1.1.min.js"></script>
 	<script src="js/bootstrap.min.js"></script><!-- los javascripts y css de las paginas-->
 </head>
 <body>
 	<div class="container"><!-- inicializa los container-->
 		<div class="row"><!-- los row-->
 			<div class="row" style="text-align: center;">
 				<?php if($resultado){?><!-- si el resultado es el esperado sale registro modificado-->
 					<h3>Registro Modificado</h3>
 			<?php } else {?><!-- sino sale error-->
 				<h3>ERROR AL MODIFICAR</h3>
 			<?php } ?>
 			<a href="indexBodega.php" class="btn btn-primary">Regresar</a><!-- sale el boton para regresar al index-->
 			</div>
 		</div>
 	</div>
 </body>
 </html>