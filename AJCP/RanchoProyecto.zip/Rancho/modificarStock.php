<?php
require 'conexion.php';
$id = $_GET['id'];
$sql = "Select * from Stock where idStock = '$id'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Registro</h3>
        </div>

        <form class="form-horizontal" method="POST" action="updateStock.php" autocomplete="on">
            <div class="form-group">
                <label for="fechaE" class="col-sm-2 control-label">id Bodega</label>
                <div class="col-sm-10">
                    <input type="int" class="form-control" id="idBodega1" name="idBodega1" value="<?php echo $row['idBodega1']; ?>">
                </div>
            </div>
            <input type="hidden" id="id" name="id" value="<?php echo $row['idStock']; ?>">


            <div class="form-group">
                <label for="fechaC" class="col-sm-2 control-label">Cantidad Stock</label>
                <div class="col-sm-10">
                    <input type="int" class="form-control" id="cantidadStock" name="cantidadStock" value="<?php echo $row['cantidadStock']; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="ambiente" class="col-sm-2 control-label">Actualizacion Stock</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" id="actualizacionStock" name="actualizacionStock" placeholder="actualizacionStock" value="<?php echo $row['actualizacionStock']; ?>">
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <br>

                    <a href="indexStock.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>