<?php
require 'Conexion.php';
$nombreEmpleado = $_POST['nombre'];
$RFC= $_POST['RFC'];
$NSS=$_POST['NSS'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$direccion =$_POST['direccion'];
$nocuenta_bancaria=$_POST['nocuenta_bancaria'];


$sql = "INSERT INTO empleado (nombreEmpleado, RFC, NSS, correoE, telefono, direccion,nocuentaBancaria) VALUES('$nombreEmpleado', '$RFC', '$NSS', '$correo', '$telefono', '$direccion', '$nocuenta_bancaria')";
$resultado = $mysqli->query($sql);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="row" style="text-align:center">
                <?php if ($resultado) { ?>
                    <h3>Registro EMPLEADO Guardado</h3>
                <?php } else { ?>
                    <h3>Error al Guardar EMPLEADO</h3>
                <?php } ?>
                <a href="indexEmpleado.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>

    </div>
</body>

</html>