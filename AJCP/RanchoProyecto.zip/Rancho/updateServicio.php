<?php
require 'Conexion.php';
$id = $_POST['id'];
$nombre = $_POST['nombre'];
$especialidad = $_POST['especialidad'];
$email = $_POST['email'];
$telefono = $_POST['telefono'];
$sql = "UPDATE Servicio SET nombreServidor ='$nombre' , especialidadS = '$especialidad', telefonoS = '$telefono', correoS = '$email' WHERE idServicio  = '$id'";
$resultado = $mysqli->query($sql);
?>

<html lang="es">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row" style="text-align:center">
                <?php if($resultado){ ?>
                    <h3>Registro modificado</h3>
                    <?php }else{ ?>
                        <h3>Error al Modificar</h3>
                        <?php } ?>
                        <a href="indexServicio.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>
    </body>
</html>