<?php
require 'conexion.php';
$id = $_GET['id'];
$sql = "Select * from Asistencia where idEmpleado1 = '$id'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Registro de Asistencia</h3>
        </div>

        <form class="form-horizontal" method="POST" action="UpdateAsistencia.php" autocomplete="on">

        <div class="form-group">
            <label for="idEmpleado1" class="col-sm-2 control-label">Id del Empleado</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="idEmpleado1" name="idEmpleado1" placeholder="Ingrese el id del empleado 0000" value="<?php echo $row['idEmpleado1']; ?>" required>
                </div>
        </div>
        <div class="form-group">
            <label for="asistencia" class="col-sm-2 control-label">Asistió a laborar</label>
                <div class="col-sm-10">
                    <label class="radio-inline">
                        <input type="radio" name="asistencia" id="asistencia" value="1" <?php if ($row['asistencia'] == '1') echo 'checked'; ?>>SI
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="asistencia" id="asistencia" value="0" <?php if ($row['asistencia'] == '0') echo 'checked'; ?>>NO
                    </label>
                </div>
        </div>

        <div class="form-group">
            <label for="falta" class="col-sm-2 control-label">Faltó a laborar</label>
                <div class="col-sm-10">
                    <label class="radio-inline">
                        <input type="radio" name="falta" id="falta" value="1" <?php if ($row['falta'] == '1') echo 'checked'; ?>>SI
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="falta" id="falta" value="0" <?php if ($row['falta'] == '0') echo 'checked'; ?>>NO
                    </label>
                </div>
        </div>

    

        <div class="form-group">
            <label for="horasExtra" class="col-sm-2 control-label">Horas extras trabajadas</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="horasExtra" name="horasExtra" placeholder="Ingrese el total de horas extra 0" value="<?php echo $row['horasExtra']; ?>" required>
                </div>
        </div>
        <div class="form-group">
            <label for="fechaA" class="col-sm-2 control-label">Fecha del registro de asistencia</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="fechaA" name="fechaA" placeholder="0000-00-00" value="<?php echo $row['fechaA']; ?>" required>
                </div>
        </div>
        <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
            <br>
                    <a href="InicioAsistencia.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>