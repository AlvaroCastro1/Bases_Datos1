<?php
	require 'conexion.php';
	$id= $_GET['id'];
	$sql ="SELECT*FROM Periodo WHERE idperiodo='$id'";
	$resultado=$mysqli->query($sql);
	$row=$resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">
	<head>
		<meta name= "viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align:center">MODIFICAR REGISTRO</h3>
			</div>
			<form class="form-horizontal" method="POST" action="update-periodo.php" autocomplete="off">
				<div class="form-group">
					<label for="idPeriodo" class="col-sm-2 control-label">ID</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="idPeriodo" name="idPeriodo" placeholder="IdPeriodo" value="<?php echo $row['idPeriodo']; ?>" required>
					</div>
				</div>

				<div class="form-group">
                <label for="inicioPeriodo" class="col-sm-2 control-label">Inicio Periodo</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" id="inicioPeriodo" name="inicioPeriodo" value="<?php echo $row['inicioPeriodo']; ?>">
                </div>
            </div>

			<div class="form-group">
                <label for="finalPeriodo" class="col-sm-2 control-label">Final Periodo</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" id="finalPeriodo" name="finalPeriodo" value="<?php echo $row['finalPeriodo']; ?>">
                </div>
            </div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<a href="index-periodo.php" class="btn btn-default">Regresar </a>
						<button type="submit" class="btn btn-primary">Guardar </button>	
					</div>
				</div>
			</form>
		</div>
	</body>
</html>