<html lang="es">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<link href="css/bootstrap.min.css" rel="stylesheet"> 
		<link href="css/bootstrap-theme.css" rel="stylesheet"> 
		<script src="js/jquery-3.1.1.min.js"></script> 
		<script src="js/bootstrap.min.js"></script>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<h3 style="text-align:center">NUEVO DEPARTAMENTO</h3> 
			</div>

			<form class="form-horizontal" method="POST" action="guardarDepto.php" autocomplete="off"> 

					<div class="form-group"> 
						<label for="idDepartamento" class="col-sm-2 control-label">ID Departamento</label> 
						<div class="col-sm-10"> 
							<input type="number" class="form-control" id="idDepartamento" name="idDepartamento" placeholder="ID Departamento" required>
						</div>
					</div>

					<div class="form-group">
						<label for="nombreDepartanmento" class="col-sm-2 control-label">Nombre Departamento</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="nombreDepartanmento" name="nombreDepartanmento" placeholder="Nombre Departamento" required>
						</div>
					</div>

					<div class="form-group">
						<label for="numEmpleados" class="col-sm-2 control-label">Numero de Empleados</label>
						<div class="col-sm-10"> 
							<input type="number" class="form-control" id="numEmpleados" name="numEmpleados" placeholder="Numero de Empleados">
						</div>
					</div>

					<div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
							<a href="indexDepto.php" class="btn btn-default">Regresar</a> 
							<button type="submit" class="btn btn-primary">Guardar</button>
						</div>
					</div>
			</form>
		</div>
	</body>
</html>
