<?php
	require 'conexion.php';

	$id = $_GET['idDepartamento'];

	$sql = "SELECT * FROM departamento WHERE idDepartamento = '$id'";
	$resultado = $mysqli->query($sql);
	$row = $resultado->fetch_array(MYSQLI_ASSOC);

?>

<html lang="es"> 
	<head>

		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<link href="css/bootstrap.min.css" rel="stylesheet"> 
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script> 
		<script src="js/bootstrap.min.js"></script>
	</head>

	<body>
		<div class="container"> 
			<div class="row">
				<h3 style="text-align:center">MODIFICAR REGISTRO</h3> 
			</div>

			<form class="form-horizontal" method="POST" action="updateDepto.php" autocomplete="off">

		<input type="hidden" id="idDepartamento" name="idDepartamento" value="<?php echo $row['idDepartamento']; ?>" /> 

		<div class="form-group">

		<label for="nombreDepartanmento" class="col-sm-2 control-label">Nombre Departanmento</label> 
		<div class="col-sm-10">
			<input type="nombreDepartanmento" class="form-control" id="nombreDepartanmento" name="nombreDepartanmento" placeholder="Nombre Departanmento" value="<?php echo $row['nombreDepartanmento']; ?>" required>
		</div>
	</div>

	<div class="form-group">
		<label for="numEmpleados" class="col-sm-2 control-label">Numero de Empleados</label>
		<div class="col-sm-10">
			<input type="numEmpleados" class="form-control" id="numEmpleados" name="numEmpleados" placeholder="Numero de Empleados" value="<?php echo $row['numEmpleados']; ?>"> 
		</div>
	</div>

	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10">
			<a href="indexDepto.php" class="btn btn-default">Regresar</a> 
			<button type="submit" class="btn btn-primary">Guardar</button>
		</div>
	</div>
</form>
</div>
</body>
</html>