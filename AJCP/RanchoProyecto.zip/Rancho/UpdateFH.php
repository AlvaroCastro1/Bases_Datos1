<?php
require 'Conexion.php';
$id = $_POST['idFacturaH'];
$id2 = $_POST['idVisitas2'];
$fechaEmisionH = $_POST['fechaEmisionH'];
$fechaVencimientoH = $_POST['fechaVencimientoH'];
$lugarEmisionH = $_POST['lugarEmisionH'];
$lugarVencimientoH = $_POST['lugarVencimientoH'];

$sql = "UPDATE FacturaHonorarios SET idVisitas2= '$id2', fechaEmisionH='$fechaEmisionH' , fechaVencimientoH = '$fechaVencimientoH', lugarEmisionH = '$lugarEmisionH', lugarVencimientoH = '$lugarVencimientoH' WHERE idFacturaH = '$id'";
$resultado = $mysqli->query($sql);
?>

<html lang="es">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row" style="text-align:center">
                <?php if($resultado){ ?>
                    <h3>Registro modificado</h3>
                    <?php }else{ ?>
                        <h3>Error al Modificar</h3>
                        <?php } ?>
                        <a href="IndexFH.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>
    </body>
</html>