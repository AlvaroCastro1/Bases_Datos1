<?php 
require 'Conexion.php';
$id = $_GET['id'];
$sql = "delete from Bodega where idBodega = '$id'";
$resultado = $mysqli->query($sql); 

 ?>

 <html lang="es"><!-- inicia el html-->
 <head>
 	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 		<link href="css/bootstrap.min.css" rel="stylesheet">
 	<link href="css/bootstrap-theme.min.css " rel="stylesheet">
 	<script src="js/jquery-3.1.1.min.js"></script>
 	<script src="js/bootstrap.min.js"></script><!-- los scripts y css de la pagina-->
 </head>
 <body>
 	<div class="container"><!-- abrimos container-->
 		<div class="row"><!-- abrimos los row-->
       <div class="row" style="text-align: center;">
            <?php if($resultado) {?><!-- si el resultado es el deseado-->
                <h3>REGISTRO ELIMINADO</h3><!-- se elimina-->
            <?php } else{ ?><!-- sino-->
                <h3>ERROR AL ELIMINAR EL REGISTRO</h3><!-- no se elimina-->
        <?php } ?>
        <a href="indexBodega.php" class="btn btn-primary">Regresar</a><!-- se agrega el boton para regresar al index-->
        </div>     
        </div>
 	</div>
 </body>
 </html>