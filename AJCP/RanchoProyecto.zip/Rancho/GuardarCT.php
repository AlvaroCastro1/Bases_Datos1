<?php
require 'Conexion.php';
    $idDetalleCompras1=$_POST['idDetalleCompras1'];
	$idPeriodo4 = $_POST['idPeriodo4'];
            $sql = "INSERT INTO ComprasTotales (idDetalleCompras1, idPeriodo4 ) VALUES(
            '$idDetalleCompras1','$idPeriodo4')";
$resultado = $mysqli->query($sql);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="row" style="text-align:center">
                <?php if ($resultado) { ?>
                    <h3>Registro Guardado</h3>
                <?php } else { ?>
                    <h3>Error al Guardar</h3>
                <?php } ?>
                <a href="IndexCT.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>

    </div>
</body>

</html>