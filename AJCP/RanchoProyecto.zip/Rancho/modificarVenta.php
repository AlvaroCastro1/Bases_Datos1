<?php
require 'Conexion.php';
$id = $_GET['id'];

$sql = "SELECT * FROM venta WHERE idVenta ='$id'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);

?>
<html lang="es">
    <head>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
        <script src="js/jquery-3.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <title>Modificar Venta</title>
    </head>

    <body style="background: #bdc3c7; background: -webkit-linear-gradient(to right, #2c3e50, #bdc3c7);  background: linear-gradient(to right, #2c3e50, #bdc3c7); ">
    	<div class="container" style="background-color: white">
    		<div class="row">
    			<h3 style="text-align:center">MODIFICAR REGISTRO</h3>
            </div>

            <form class="form-horizontal" method="POST" action="updateVenta.php ? id=<?php echo $_GET['id']; ?>"  autocomplete="off">
            	
            <div class="form-group row">
                    <label for="fechaVenta" class="col-sm-2 control-label">Fecha</label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" id="fechaVenta" name="fechaVenta"  value="<?php echo $row['fechaVenta']; ?>" required>
                    </div>
                </div>
                

                <div class="form-group row">
                    <label for="IVA" class="col-sm-2 control-label">IVA</label>
                    <div class="col-sm-10">
                        <input type="number" min="0" max="16" step=".1" class="form-control" id="IVA" name="IVA" value="<?php echo $row['iva']; ?>" required >
                    </div>
                </div>

                <div class="form-group row">
                    <label for="Total" class="col-sm-2 control-label">Total</label>
                    <div class="col-sm-10">
                        <input type="number" min="0" step=".1" class="form-control" id="Total" name="Total" value="<?php echo $row['total']; ?>" required >
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm--offset-2 col-sm-10">
                        <a href="indexVenta.php" class="btn btn-default">Regresar</a>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
            
                </div>
            </form>
        </div>
    </body>
</html>



