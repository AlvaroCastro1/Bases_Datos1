<?php
//se conecta a la base de datos
require 'conexion.php';
//se le asignan valores a las variables
$idProductos = $_GET['idProducto'];
//se determina el proceso que se realizara
$sql = "Delete from Producto where idProducto = '$idProductos'";
$resultado = $mysqli->query($sql);
?>
<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="row" style="text-align:centar">
                <!--se muestra el resultado de la table-->
                <?php if ($resultado) { ?>
                    <h3>Registro Eliminado</h3>
                <?php } else { ?>
                    <h3>Error al Eliminar</h3>
                <?php } ?>
                <a href="indexProducto.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>
    </div>
</body>

</html>
