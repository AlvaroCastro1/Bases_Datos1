<?php
	require 'Conexion.php';

	$id= $_GET['id'];
	$sql ="DELETE FROM DetalleProceso WHERE idDetalleProceso='$id'";
	$resultado=$mysqli->query($sql);
?>

<html>
	<head>
		<meta name= "viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>			
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="row" style="text-align: center">
				<?php if($resultado){ ?>
				<h3>REGISTRO ELIMINADO </h3>
				<?php } else{ ?>
				<h3>ERROR AL ELIMINAR</h3>
				<?php } ?>

			<a href="indexDetalleProceso.php" class="btn btn.primary"> Regresar </a>
				</div>
			</div>
		</div>
	
	</body>
</html>