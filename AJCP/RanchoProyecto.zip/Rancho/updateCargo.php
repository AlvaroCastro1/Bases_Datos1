<?php
require 'Conexion.php';
$idCargo = $_POST['idCargo'];
$idJornada1 = $_POST['idJornada1'];
$nombreCargo = $_POST['nombreCargo'];
$descripcion = $_POST['descripcion'];

$sql = "UPDATE Cargo SET idJornada1='$idJornada1' , nombreCargo='$nombreCargo', descripcion = '$descripcion' WHERE idCargo = '$idCargo'";
$resultado = $mysqli->query($sql);
?>

<html lang="es">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row" style="text-align:center">

                <?php if($resultado){ ?>
                    <h3>Registro modificado</h3>
                    <?php }else{ ?>
                        <h3>Error al Modificar</h3>
                        <?php } ?>
                        <a href="indexCargo.php" class="btn btn-primary">Regresar</a>
            </div>
        </div>
    </body>
</html>