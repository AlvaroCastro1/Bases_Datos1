<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="">
    </head>
    <body>
    <body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Nuevo Registro</h3>
        </div>
        <form class="form-horizontal" method="POST" action="guardarProducto.php" autocomplete="on">
            <div class="form-group">
                <!--Se crea un label que indicara donde se coloca el nombre-->
                <label for="idStock1" class="col-sm-2 control-label">id del Stock</label>
                <div class="col-sm-10">
                    <!--se crea un area para ingresar el nombre-->
                    <input type="idStock1" class="form-control" id="idStock1" name="idStock1" placeholder="id del Stock" required>
                </div>
            </div>

            <div class="form-group">
                <!--Se crea un label que indicara donde se coloca el correo-->
                <label for="nombreProducto" class="col-sm-2 control-label">Nombre</label>
                <div class="col-sm-10">
                    <!--se crea un area para ingresar el correo-->
                    <input type="nombreProducto" class="form-control" id="nombreProducto" name="nombreProducto" placeholder="Nombre" required>
                </div>
            </div>

            <div class="form-group">
                <!--Se crea un label que indicara donde se coloca el telefono-->
                <label for="precioProducto" class="col-sm-2 control-label">Precio</label>
                <div class="col-sm-10">
                    <!--se crea un area para ingresar el telefono-->
                    <input type="precioProducto" class="form-control" id="precioProducto" name="precioProducto" placeholder="Precio" required>
                </div>
            </div>

            <div class="form-group">
                <!--Se crea un label que indicara donde se elegir la universidad de egreso-->
                <label for="tipoUnidad" class="col-sm-2 control-label">Tipo de unidad</label>
                <div class="col-sm-10">
                    <!--se crea un select para dar las opciones de la universidad-->
                    <select class="form-control" id="tipoUnidad" name="tipoUnidad">
                        <option value="kilogramo">kilogramo</option>
                        <option value="gramo">gramo</option>
                        <option value="litro">Litro</option>
                        <option value="mililitro">mililitro</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <!--Se crea un label que indicara donde se coloca el telefono-->
                <label for="cantidad" class="col-sm-2 control-label">Cantidad</label>
                <div class="col-sm-10">
                    <!--se crea un area para ingresar el telefono-->
                    <input type="cantidad" class="form-control" id="cantidad" name="cantidad" placeholder="Cantidad" required>
                </div>
            </div>

            <div class="form-group">
                <!--Se crea un label que indicara donde se coloca el telefono-->
                <label for="descripcion" class="col-sm-2 control-label">Descripcion</label>
                <div class="col-sm-10">
                    <!--se crea un area para ingresar el telefono-->
                    <input type="descripcion" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion" required>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <!--Se crean dos botones, uno para regresar y uno para guardar-->
                    <a href="indexProducto.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>

        </form>

    </div>
</body>

</html>
    </body>
</html>
