<?php
require 'Conexion.php';
$id = $_GET['id'];
$sql = "Select * from Proveedores where idProveedor = '$id'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);
?>

<html lang="es">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <h3 style="text-align:center">Modificar Registro</h3>
        </div>

        <form class="form-horizontal" method="POST" action="UpdateProv.php" autocomplete="on">
            <div class="form-group">
                <label for="razonSocial" class="col-sm-2 control-label">Razon Social</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="razonSocial" name="razonSocial" placeholder="razonSocial" value="<?php echo $row['razonSocial']; ?>" required>
                </div>
            </div>
            <input type="hidden" id="idProveedor" name="idProveedor" value="<?php echo $row['idProveedor']; ?>">

            <div class="form-group">
                <label for="estado" class="col-sm-2 control-label">Estado</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="estado" name="estado" placeholder="estado" value="<?php echo $row['estado']; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="municipio" class="col-sm-2 control-label">Municipio</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="municipio" name="municipio" placeholder="municipio" value="<?php echo $row['municipio']; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="colonia" class="col-sm-2 control-label">Colonia</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="colonia" name="colonia" placeholder="colonia" value="<?php echo $row['colonia']; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="calle" class="col-sm-2 control-label">Calle</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="calle" name="calle" placeholder="calle" value="<?php echo $row['calle']; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="numExt" class="col-sm-2 control-label">Numero Exterior</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="numExt" name="numExt" placeholder="numExt" value="<?php echo $row['numExt']; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="numInt" class="col-sm-2 control-label">Numero Interior</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="numInt" name="numInt" placeholder="numInt" value="<?php echo $row['numInt']; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="CP" class="col-sm-2 control-label">CP</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="CP" name="CP" placeholder="CP" value="<?php echo $row['CP']; ?>">
                </div>
            </div>
            

            <div class="form-group">
                <label for="telefono" class="col-sm-2 control-label">Telefono</label>
                <div class="col-sm-10">
                    <input type="telefono" class="form-control" id="telefono" name="telefono" placeholder="Telefono" value="<?php echo $row['telefono']; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="correo" class="col-sm-2 control-label">Correo</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" id="correo" name="correo" placeholder="correo" value="<?php echo $row['correo']; ?>">
                </div>
            </div>


            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
            <br>

                    <a href="IndexProv.php" class="btn btn-default">Regresar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </form>
    </div>
</body>

</html>